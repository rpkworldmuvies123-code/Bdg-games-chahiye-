// Simple file-based JSON store — atomic writes, in-memory cache.
// Good enough for cPanel shared hosting / small-medium load.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = path.join(__dirname, 'data', 'data.json');

function defaultData() {
  return {
    users: {},          // id -> { id, username, passwordHash, balance, createdAt, banned }
    sessions: {},       // token -> { userId, role, exp }
    transactions: [],   // {id, userId, type, method, amount, status, account, ts, note}
    bets: [],           // {id, userId, game, stake, payout, result, ts}
    wingoHistory: [],   // {period, number, color, ts, manual}
    wingoOverrides: {}, // period -> number (admin override)
    games: {},          // id -> { id, enabled, minBet, maxBet, rtp, ... }
    settings: {
      siteName: 'BDG PRO',
      startingBalance: 1000,
      minDeposit: 100,
      minWithdraw: 100,
      autoApproveWithdraw: false,
      currency: 'INR',
    },
    stats: {
      totalDeposits: 0,
      totalWithdrawals: 0,
      totalBets: 0,
      totalPayouts: 0,
      dailySnapshots: [], // {date, deposits, withdrawals, bets, payouts, ggr}
    },
  };
}

let cache = null;
let writeQueued = false;

function load() {
  if (cache) return cache;
  try {
    if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    if (fs.existsSync(DATA_FILE)) {
      cache = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      // Merge defaults for any missing keys (forward-compat)
      const d = defaultData();
      for (const k of Object.keys(d)) if (cache[k] === undefined) cache[k] = d[k];
    } else {
      cache = defaultData();
      save();
    }
  } catch (e) {
    console.error('Data load error:', e.message);
    cache = defaultData();
  }
  return cache;
}

function save() {
  if (writeQueued) return;
  writeQueued = true;
  setImmediate(() => {
    writeQueued = false;
    try {
      const tmp = DATA_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(cache, null, 2));
      fs.renameSync(tmp, DATA_FILE);
    } catch (e) {
      console.error('Data save error:', e.message);
    }
  });
}

function uid() { return crypto.randomBytes(8).toString('hex'); }
function token() { return crypto.randomBytes(24).toString('hex'); }

module.exports = { load, save, uid, token, defaultData };
