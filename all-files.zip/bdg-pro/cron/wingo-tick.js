// Wingo tick — pre-generate next round result if not present. Optional cron job.
// Not strictly necessary because /api/wingo/draw lazily generates, but useful
// if you want server-driven scheduled draws independent of client requests.
const { load, save } = require('../store');

function numColor(n){ if (n===0) return ['red','violet']; if (n===5) return ['green','violet']; return [n%2===0?'red':'green']; }

function run() {
  const d = load();
  const now = Date.now();
  const period = Math.floor(now / 60_000) - 1; // settle previous period
  if (d.wingoHistory.find(h => h.period === period)) {
    console.log(`[wingo] already drawn for period ${period}`);
    return;
  }
  let n;
  if (d.wingoOverrides[period] != null) {
    n = Math.max(0, Math.min(9, Math.floor(d.wingoOverrides[period])));
    delete d.wingoOverrides[period];
  } else {
    n = Math.floor(Math.random() * 10);
  }
  d.wingoHistory.push({ period, number: n, color: numColor(n), big: n>=5, ts: now });
  if (d.wingoHistory.length > 200) d.wingoHistory.shift();
  save();
  console.log(`[wingo] drew ${n} (${numColor(n).join('+')}) for period ${period}`);
}

if (require.main === module) run();
module.exports = { run };
