// Clean up expired sessions and stale wingo data
const { load, save } = require('../store');

function run() {
  const d = load();
  const now = Date.now();
  let removed = 0;
  for (const t of Object.keys(d.sessions)) {
    if (d.sessions[t].exp < now) { delete d.sessions[t]; removed++; }
  }
  // Trim wingo history
  if (d.wingoHistory.length > 200) d.wingoHistory = d.wingoHistory.slice(-200);
  // Clear stale overrides (period < now-60)
  const currentPeriod = Math.floor(now / 60_000);
  for (const p of Object.keys(d.wingoOverrides)) {
    if (Number(p) < currentPeriod - 5) delete d.wingoOverrides[p];
  }
  save();
  console.log(`[cleanup] removed ${removed} expired sessions`);
}

if (require.main === module) run();
module.exports = { run };
