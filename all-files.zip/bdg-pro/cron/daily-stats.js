// Daily stats rollup — run once a day via cron
const { load, save } = require('../store');

function run() {
  const d = load();
  const today = new Date().toISOString().slice(0, 10);
  // Snapshot today's totals
  const last = d.stats.dailySnapshots[d.stats.dailySnapshots.length - 1];
  const snap = {
    date: today,
    deposits: d.stats.totalDeposits,
    withdrawals: d.stats.totalWithdrawals,
    bets: d.stats.totalBets,
    payouts: d.stats.totalPayouts,
    ggr: +(d.stats.totalBets - d.stats.totalPayouts).toFixed(2),
    users: Object.keys(d.users).length,
  };
  if (last && last.date === today) {
    Object.assign(last, snap);
  } else {
    d.stats.dailySnapshots.push(snap);
  }
  // Trim old bets (keep latest 5000)
  if (d.bets.length > 5000) d.bets.length = 5000;
  // Trim transactions older than 90 days (keep at least 1000 most recent regardless)
  const cutoff = Date.now() - 90*24*60*60*1000;
  const kept = d.transactions.filter((t,i) => i < 1000 || t.ts >= cutoff);
  d.transactions = kept;
  save();
  console.log(`[daily-stats] snapshot saved for ${today}: GGR ₹${snap.ggr.toFixed(2)}`);
}

if (require.main === module) run();
module.exports = { run };
