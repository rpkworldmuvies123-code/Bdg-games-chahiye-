// BDG PRO — Demo gaming platform with admin panel
// Simulated wallet only. No real money handling.
const express = require('express');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const path = require('path');
const { load, save, uid, token } = require('./store');

const app = express();
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());

// ---- Default games registry ----
const DEFAULT_GAMES = [
  { id:'wingo',name:'Win Go',tag:'Color Prediction',hot:true,emoji:'🎯',color:'#ff5b6e' },
  { id:'aviator',name:'Aviator',tag:'Crash',hot:true,emoji:'✈️',color:'#e63946' },
  { id:'mines',name:'Mines',tag:'Reveal & Win',hot:true,emoji:'💣',color:'#ffb703' },
  { id:'plinko',name:'Plinko',tag:'Drop & Bounce',hot:false,emoji:'🟡',color:'#48cae4' },
  { id:'dice',name:'Dice',tag:'Roll Over/Under',hot:false,emoji:'🎲',color:'#06d6a0' },
  { id:'wheel',name:'Lucky Wheel',tag:'Spin & Win',hot:true,emoji:'🎡',color:'#f72585' },
  { id:'slots',name:'BDG Slots',tag:'81 Ways',hot:true,emoji:'🎰',color:'#ffd60a' },
  { id:'limbo',name:'Limbo',tag:'Multiplier',hot:false,emoji:'🚀',color:'#7209b7' },
  { id:'hilo',name:'Hi-Lo',tag:'Higher / Lower',hot:false,emoji:'🃏',color:'#4361ee' },
  { id:'coinflip',name:'Coin Flip',tag:'Heads or Tails',hot:false,emoji:'🪙',color:'#ffaa00' },
  { id:'roulette',name:'Mini Roulette',tag:'Casino Classic',hot:true,emoji:'🎯',color:'#b5179e' },
  { id:'keno',name:'Keno',tag:'Pick & Match',hot:false,emoji:'🔢',color:'#3a86ff' },
  { id:'andarbahar',name:'Andar Bahar',tag:'Indian Classic',hot:true,emoji:'🂠',color:'#ff006e' },
  { id:'dragontiger',name:'Dragon vs Tiger',tag:'50/50 Showdown',hot:true,emoji:'🐉',color:'#ff3838' },
  { id:'rps',name:'Rock Paper Scissors',tag:'Quick Match',hot:false,emoji:'✊',color:'#fb5607' },
  { id:'scratch',name:'Scratch Card',tag:'Instant Win',hot:false,emoji:'🎟️',color:'#ff9f1c' },
  { id:'lucky7',name:'Lucky 7',tag:'Above / Below 7',hot:false,emoji:'7️⃣',color:'#2ec4b6' },
  { id:'tower',name:'Tower',tag:'Climb to Win',hot:false,emoji:'🗼',color:'#8338ec' },
  { id:'blackjack',name:'Blackjack',tag:'Beat the Dealer',hot:true,emoji:'♠️',color:'#1f7a8c' },
  { id:'sicbo',name:'Sic Bo',tag:'3 Dice',hot:false,emoji:'🎲',color:'#e76f51' },
  { id:'teenpatti',name:'Teen Patti',tag:'Indian Poker',hot:true,emoji:'🃏',color:'#d62828' },
  { id:'crash2',name:'Rocket Crash',tag:'Multiplier',hot:false,emoji:'🚀',color:'#ef476f' },
];

// ---- Bootstrap admin + games ----
function bootstrap() {
  const d = load();
  // Seed games registry
  for (const g of DEFAULT_GAMES) {
    if (!d.games[g.id]) {
      d.games[g.id] = { ...g, enabled: true, minBet: 1, maxBet: 10000, rtp: 97, plays: 0, ggr: 0 };
    } else {
      // Keep settings, refresh display props
      Object.assign(d.games[g.id], { name:g.name, tag:g.tag, emoji:g.emoji, color:g.color });
    }
  }
  // Seed admin user
  if (!Object.values(d.users).some(u => u.role === 'admin')) {
    const id = uid();
    d.users[id] = {
      id, username: 'admin', role: 'admin',
      passwordHash: bcrypt.hashSync('admin123', 8),
      balance: 0, createdAt: Date.now(), banned: false,
    };
    console.log('Seeded admin: admin / admin123');
  }
  save();
}
bootstrap();

// ---- Auth middleware ----
function getUser(req) {
  const t = req.cookies?.sid;
  if (!t) return null;
  const d = load();
  const s = d.sessions[t];
  if (!s || s.exp < Date.now()) {
    if (s) { delete d.sessions[t]; save(); }
    return null;
  }
  const u = d.users[s.userId];
  if (!u || u.banned) return null;
  return { ...u, sessionToken: t };
}
function requireAuth(req, res, next) {
  const u = getUser(req);
  if (!u) return res.status(401).json({ error: 'auth required' });
  req.user = u;
  next();
}
function requireAdmin(req, res, next) {
  const u = getUser(req);
  if (!u || u.role !== 'admin') return res.status(403).json({ error: 'admin only' });
  req.user = u;
  next();
}

// ---- Auth endpoints ----
app.post('/api/auth/signup', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || username.length < 3 || username.length > 20) return res.status(400).json({ error: 'Username 3-20 chars' });
  if (!password || password.length < 4) return res.status(400).json({ error: 'Password min 4 chars' });
  const d = load();
  if (Object.values(d.users).some(u => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(400).json({ error: 'Username taken' });
  const id = uid();
  d.users[id] = {
    id, username, role: 'user',
    passwordHash: bcrypt.hashSync(password, 8),
    balance: d.settings.startingBalance, createdAt: Date.now(), banned: false,
  };
  const t = token();
  d.sessions[t] = { userId: id, role: 'user', exp: Date.now() + 7*24*60*60*1000 };
  save();
  res.cookie('sid', t, { httpOnly: true, sameSite: 'lax', maxAge: 7*24*60*60*1000 });
  res.json({ ok: true, user: { id, username, role: 'user', balance: d.users[id].balance } });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const d = load();
  const u = Object.values(d.users).find(u => u.username.toLowerCase() === (username||'').toLowerCase());
  if (!u || !bcrypt.compareSync(password||'', u.passwordHash)) return res.status(400).json({ error: 'Invalid credentials' });
  if (u.banned) return res.status(403).json({ error: 'Account banned' });
  const t = token();
  d.sessions[t] = { userId: u.id, role: u.role, exp: Date.now() + 7*24*60*60*1000 };
  save();
  res.cookie('sid', t, { httpOnly: true, sameSite: 'lax', maxAge: 7*24*60*60*1000 });
  res.json({ ok: true, user: { id: u.id, username: u.username, role: u.role, balance: u.balance } });
});

app.post('/api/auth/logout', (req, res) => {
  const t = req.cookies?.sid;
  if (t) { const d = load(); delete d.sessions[t]; save(); }
  res.clearCookie('sid');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const u = getUser(req);
  if (!u) return res.json({ user: null });
  res.json({ user: { id: u.id, username: u.username, role: u.role, balance: u.balance } });
});

// ---- Wallet ----
app.get('/api/wallet', requireAuth, (req, res) => {
  const d = load();
  const history = d.transactions.filter(t => t.userId === req.user.id).slice(0, 30);
  res.json({ balance: req.user.balance, currency: d.settings.currency, history });
});

app.post('/api/deposit', requireAuth, (req, res) => {
  const { amount, method } = req.body || {};
  const amt = Number(amount);
  const d = load();
  if (!amt || amt < d.settings.minDeposit) return res.status(400).json({ error: `Min deposit ₹${d.settings.minDeposit}` });
  if (!['upi','usdt'].includes(method)) return res.status(400).json({ error: 'Invalid method' });
  const tx = {
    id: uid(), userId: req.user.id, username: req.user.username,
    type: 'deposit', method, amount: amt, status: 'success',
    note: `Simulated ${method.toUpperCase()} deposit`, ts: Date.now(),
  };
  d.users[req.user.id].balance = +(d.users[req.user.id].balance + amt).toFixed(2);
  d.transactions.unshift(tx);
  d.stats.totalDeposits = +(d.stats.totalDeposits + amt).toFixed(2);
  save();
  res.json({ ok: true, balance: d.users[req.user.id].balance, txId: tx.id });
});

app.post('/api/withdraw', requireAuth, (req, res) => {
  const { amount, method, account } = req.body || {};
  const amt = Number(amount);
  const d = load();
  if (!amt || amt < d.settings.minWithdraw) return res.status(400).json({ error: `Min withdraw ₹${d.settings.minWithdraw}` });
  if (amt > req.user.balance) return res.status(400).json({ error: 'Insufficient balance' });
  if (!['bank','upi','usdt'].includes(method)) return res.status(400).json({ error: 'Invalid method' });
  if (!account || String(account).trim().length < 3) return res.status(400).json({ error: 'Account required' });
  d.users[req.user.id].balance = +(d.users[req.user.id].balance - amt).toFixed(2);
  const tx = {
    id: uid(), userId: req.user.id, username: req.user.username,
    type: 'withdraw', method, account: String(account), amount: amt,
    status: d.settings.autoApproveWithdraw ? 'success' : 'pending',
    note: 'Simulated payout', ts: Date.now(),
  };
  d.transactions.unshift(tx);
  if (tx.status === 'success') d.stats.totalWithdrawals = +(d.stats.totalWithdrawals + amt).toFixed(2);
  save();
  res.json({ ok: true, balance: d.users[req.user.id].balance, status: tx.status, txId: tx.id });
});

// ---- Bet settle ----
app.post('/api/settle', requireAuth, (req, res) => {
  const { game, stake, payout, result } = req.body || {};
  const s = Math.max(0, Number(stake)||0);
  const p = Math.max(0, Number(payout)||0);
  const d = load();
  if (!d.games[game]) return res.status(400).json({ error: 'Unknown game' });
  if (!d.games[game].enabled) return res.status(403).json({ error: 'Game disabled by admin' });
  if (s > d.games[game].maxBet) return res.status(400).json({ error: `Max bet ₹${d.games[game].maxBet}` });
  if (s && s < d.games[game].minBet) return res.status(400).json({ error: `Min bet ₹${d.games[game].minBet}` });
  if (s > req.user.balance + 0.001) return res.status(400).json({ error: 'Insufficient balance' });
  d.users[req.user.id].balance = +(d.users[req.user.id].balance - s + p).toFixed(2);
  const bet = { id: uid(), userId: req.user.id, username: req.user.username, game, stake: s, payout: p, result: String(result||''), ts: Date.now() };
  d.bets.unshift(bet);
  if (d.bets.length > 5000) d.bets.length = 5000;
  d.stats.totalBets = +(d.stats.totalBets + s).toFixed(2);
  d.stats.totalPayouts = +(d.stats.totalPayouts + p).toFixed(2);
  d.games[game].plays = (d.games[game].plays || 0) + 1;
  d.games[game].ggr = +((d.games[game].ggr || 0) + (s - p)).toFixed(2);
  save();
  res.json({ ok: true, balance: d.users[req.user.id].balance });
});

// ---- Wingo (Color Prediction) ----
function numColor(n){ if (n===0) return ['red','violet']; if (n===5) return ['green','violet']; return [n%2===0?'red':'green']; }

app.get('/api/wingo/state', (req, res) => {
  const now = Date.now();
  const periodLen = 60_000;
  const period = Math.floor(now / periodLen);
  const remaining = periodLen - (now % periodLen);
  const d = load();
  res.json({
    period, remaining,
    history: d.wingoHistory.slice(-15).reverse(),
  });
});

app.post('/api/wingo/draw', (req, res) => {
  const { period } = req.body || {};
  const d = load();
  // Reuse if already drawn for this period (so all clients see same result)
  let existing = d.wingoHistory.find(h => h.period === period);
  if (existing) return res.json(existing);
  // Admin override?
  let n;
  if (d.wingoOverrides[period] != null) {
    n = Math.max(0, Math.min(9, Math.floor(d.wingoOverrides[period])));
    delete d.wingoOverrides[period];
  } else {
    n = Math.floor(Math.random() * 10);
  }
  const result = { period, number: n, color: numColor(n), big: n >= 5, ts: Date.now() };
  d.wingoHistory.push(result);
  if (d.wingoHistory.length > 200) d.wingoHistory.shift();
  save();
  res.json(result);
});

// ---- Bet history ----
app.get('/api/bets', requireAuth, (req, res) => {
  const d = load();
  res.json(d.bets.filter(b => b.userId === req.user.id).slice(0, 100));
});

app.get('/api/bets/by-game/:game', requireAuth, (req, res) => {
  const d = load();
  res.json(d.bets.filter(b => b.userId === req.user.id && b.game === req.params.game).slice(0, 50));
});

// ---- Games list (enabled only for public) ----
app.get('/api/games', (req, res) => {
  const d = load();
  const u = getUser(req);
  const list = Object.values(d.games)
    .filter(g => u?.role === 'admin' || g.enabled)
    .map(g => ({ id:g.id, name:g.name, tag:g.tag, hot:!!g.hot, emoji:g.emoji, color:g.color, enabled:g.enabled, minBet:g.minBet, maxBet:g.maxBet }));
  res.json(list);
});

// =====================================================================
// ============================ ADMIN API ==============================
// =====================================================================
const admin = express.Router();
admin.use(requireAdmin);

admin.get('/stats', (req, res) => {
  const d = load();
  const users = Object.values(d.users);
  res.json({
    users: users.length,
    activeUsers: users.filter(u => u.role !== 'admin').length,
    totalBalance: +users.reduce((s,u) => s+u.balance, 0).toFixed(2),
    deposits: d.stats.totalDeposits,
    withdrawals: d.stats.totalWithdrawals,
    bets: d.stats.totalBets,
    payouts: d.stats.totalPayouts,
    ggr: +(d.stats.totalBets - d.stats.totalPayouts).toFixed(2),
    pendingWithdrawals: d.transactions.filter(t => t.type==='withdraw' && t.status==='pending').length,
    recentBets: d.bets.slice(0, 10),
    recentTransactions: d.transactions.slice(0, 10),
    dailySnapshots: d.stats.dailySnapshots.slice(-30),
  });
});

admin.get('/users', (req, res) => {
  const d = load();
  const q = (req.query.q || '').toLowerCase();
  const users = Object.values(d.users)
    .filter(u => !q || u.username.toLowerCase().includes(q))
    .map(u => ({ id:u.id, username:u.username, role:u.role, balance:u.balance, createdAt:u.createdAt, banned:u.banned }))
    .sort((a,b) => b.createdAt - a.createdAt);
  res.json(users);
});

admin.post('/users/:id', (req, res) => {
  const d = load();
  const u = d.users[req.params.id];
  if (!u) return res.status(404).json({ error: 'Not found' });
  const { balance, banned, password } = req.body || {};
  if (balance !== undefined) u.balance = +Number(balance).toFixed(2);
  if (banned !== undefined) u.banned = !!banned;
  if (password) u.passwordHash = bcrypt.hashSync(String(password), 8);
  save();
  res.json({ ok: true });
});

admin.post('/users/:id/adjust', (req, res) => {
  const d = load();
  const u = d.users[req.params.id];
  if (!u) return res.status(404).json({ error: 'Not found' });
  const delta = Number(req.body.delta || 0);
  const note = String(req.body.note || 'Admin adjustment');
  u.balance = +(u.balance + delta).toFixed(2);
  d.transactions.unshift({
    id: uid(), userId: u.id, username: u.username,
    type: delta >= 0 ? 'deposit' : 'withdraw',
    method: 'admin', amount: Math.abs(delta), status: 'success', note, ts: Date.now(),
  });
  save();
  res.json({ ok: true, balance: u.balance });
});

admin.delete('/users/:id', (req, res) => {
  const d = load();
  const u = d.users[req.params.id];
  if (!u) return res.status(404).json({ error: 'Not found' });
  if (u.role === 'admin') return res.status(400).json({ error: 'Cannot delete admin' });
  delete d.users[req.params.id];
  // Drop sessions
  for (const t of Object.keys(d.sessions)) if (d.sessions[t].userId === req.params.id) delete d.sessions[t];
  save();
  res.json({ ok: true });
});

admin.get('/transactions', (req, res) => {
  const d = load();
  const { type, status, q } = req.query;
  let list = d.transactions.slice();
  if (type) list = list.filter(t => t.type === type);
  if (status) list = list.filter(t => t.status === status);
  if (q) list = list.filter(t => (t.username||'').toLowerCase().includes(String(q).toLowerCase()));
  res.json(list.slice(0, 500));
});

admin.post('/transactions/:id/approve', (req, res) => {
  const d = load();
  const t = d.transactions.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Not found' });
  if (t.type !== 'withdraw' || t.status !== 'pending') return res.status(400).json({ error: 'Not a pending withdrawal' });
  t.status = 'success'; t.processedAt = Date.now();
  d.stats.totalWithdrawals = +(d.stats.totalWithdrawals + t.amount).toFixed(2);
  save();
  res.json({ ok: true });
});

admin.post('/transactions/:id/reject', (req, res) => {
  const d = load();
  const t = d.transactions.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Not found' });
  if (t.type !== 'withdraw' || t.status !== 'pending') return res.status(400).json({ error: 'Not a pending withdrawal' });
  // Refund balance
  const u = d.users[t.userId];
  if (u) u.balance = +(u.balance + t.amount).toFixed(2);
  t.status = 'rejected'; t.processedAt = Date.now();
  save();
  res.json({ ok: true });
});

admin.get('/bets', (req, res) => {
  const d = load();
  const { game, user } = req.query;
  let list = d.bets.slice();
  if (game) list = list.filter(b => b.game === game);
  if (user) list = list.filter(b => (b.username||'').toLowerCase().includes(String(user).toLowerCase()));
  res.json(list.slice(0, 500));
});

admin.get('/games', (req, res) => {
  const d = load();
  res.json(Object.values(d.games));
});

admin.post('/games/:id', (req, res) => {
  const d = load();
  const g = d.games[req.params.id];
  if (!g) return res.status(404).json({ error: 'Not found' });
  const { enabled, minBet, maxBet, rtp, hot } = req.body || {};
  if (enabled !== undefined) g.enabled = !!enabled;
  if (hot !== undefined) g.hot = !!hot;
  if (minBet !== undefined) g.minBet = Math.max(1, Number(minBet)||1);
  if (maxBet !== undefined) g.maxBet = Math.max(g.minBet, Number(maxBet)||10000);
  if (rtp !== undefined) g.rtp = Math.max(50, Math.min(99, Number(rtp)||97));
  save();
  res.json({ ok: true, game: g });
});

admin.get('/wingo/upcoming', (req, res) => {
  const d = load();
  const period = Math.floor(Date.now() / 60_000);
  res.json({ period, next: period + 1, overrides: d.wingoOverrides });
});

admin.post('/wingo/override', (req, res) => {
  const { period, number } = req.body || {};
  const d = load();
  const p = Number(period), n = Number(number);
  if (!Number.isInteger(p) || n<0 || n>9) return res.status(400).json({ error: 'Bad period or number 0-9' });
  d.wingoOverrides[p] = n;
  save();
  res.json({ ok: true });
});

admin.delete('/wingo/override/:period', (req, res) => {
  const d = load();
  delete d.wingoOverrides[Number(req.params.period)];
  save();
  res.json({ ok: true });
});

admin.get('/settings', (req, res) => res.json(load().settings));
admin.post('/settings', (req, res) => {
  const d = load();
  Object.assign(d.settings, req.body || {});
  save();
  res.json({ ok: true, settings: d.settings });
});

app.use('/api/admin', admin);

// ---- Cron-callable endpoints (optional, for cPanel cron via wget) ----
// Protect with token from settings or env
app.post('/api/cron/:job', (req, res) => {
  const expected = process.env.CRON_TOKEN || 'changeme';
  if ((req.headers['x-cron-token'] || req.query.token) !== expected) return res.status(403).json({ error: 'bad token' });
  const job = req.params.job;
  if (job === 'daily-stats') {
    require('./cron/daily-stats').run();
    return res.json({ ok: true });
  }
  if (job === 'cleanup-sessions') {
    require('./cron/cleanup-sessions').run();
    return res.json({ ok: true });
  }
  res.status(404).json({ error: 'unknown job' });
});

// ---- Static after API ----
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`BDG Pro listening on http://localhost:${PORT}`));
