# BDG Pro — cPanel Deployment Guide

**This is a demo platform. No real money, no real payment gateway.**
Only deploy as a UI/UX showcase, portfolio piece, or learning project. Real-money
gaming/gambling is restricted or illegal in many jurisdictions (most Indian states
included). You are responsible for any legal consequences.

---

## 1. Upload files

Zip the project folder and upload via cPanel File Manager:

```
bdg-pro/
├── server.js
├── store.js
├── package.json
├── cron/
├── data/         (auto-created on first run; make sure it's writable: chmod 755)
├── public/
└── node_modules/ (or install via cPanel)
```

Place it under `~/apps/bdg-pro` (or any folder outside `public_html`).

## 2. Create a Node.js app in cPanel

cPanel → **Setup Node.js App** → **Create Application**:

| Field            | Value                          |
|------------------|--------------------------------|
| Node.js version  | 18.x or higher                 |
| Application mode | Production                     |
| Application root | `apps/bdg-pro`                 |
| Application URL  | yourdomain.com (or subdomain)  |
| Startup file     | `server.js`                    |

Add environment variables:

| Name        | Value          | Notes                                   |
|-------------|----------------|------------------------------------------|
| PORT        | (auto)         | cPanel sets this; do not override        |
| CRON_TOKEN  | random string  | Used to authenticate cron URL calls      |

Click **Create**, then **Run NPM Install** to install dependencies.
Finally click **Start App**.

## 3. First-time admin login

Default admin account is auto-seeded on first run:

- Username: `admin`
- Password: `admin123`

**Change this immediately** in the Admin panel → Users → admin → Set new password.

## 4. Cron Jobs

cPanel → **Cron Jobs**. Two recommended setups:

### Option A — Run Node scripts directly (preferred)

Replace `/home/USER/apps/bdg-pro/` with your actual path.

```
# Daily stats rollup — once at midnight
0 0 * * * cd /home/USER/apps/bdg-pro && /usr/bin/node cron/daily-stats.js >> data/cron.log 2>&1

# Cleanup expired sessions — every hour
0 * * * * cd /home/USER/apps/bdg-pro && /usr/bin/node cron/cleanup-sessions.js >> data/cron.log 2>&1

# Wingo round tick — every minute (optional, only if you want server-driven draws)
* * * * * cd /home/USER/apps/bdg-pro && /usr/bin/node cron/wingo-tick.js >> data/cron.log 2>&1
```

Adjust the node path. cPanel's Node app sets up a custom env — use the **NodeJS Selector**
binary if `/usr/bin/node` is the wrong version:
```
/home/USER/nodevenv/apps/bdg-pro/18/bin/node
```

### Option B — Trigger via HTTP (when shell node isn't available)

```
0 0 * * * /usr/bin/wget -qO- --header="x-cron-token: YOUR_CRON_TOKEN" https://yourdomain.com/api/cron/daily-stats
0 * * * * /usr/bin/wget -qO- --header="x-cron-token: YOUR_CRON_TOKEN" https://yourdomain.com/api/cron/cleanup-sessions
```

## 5. Reverse-proxy / Subdomain notes

If you serve via a subdomain (e.g. `play.yourdomain.com`), make sure the cPanel
Node app URL matches it. cPanel automatically generates a `.htaccess` Passenger
proxy in `public_html`.

For Apache/Nginx in front, proxy all paths to the app port. WebSockets not used,
so simple HTTP proxy is enough.

## 6. Data persistence

All data lives in `data/data.json`. **Back this up regularly** — that's your
users, balances, bets, and transaction history.

```
0 3 * * * cp /home/USER/apps/bdg-pro/data/data.json /home/USER/backups/bdg-$(date +\%F).json
```

## 7. Hardening checklist (for demo deployment)

- [ ] Change admin password
- [ ] Set strong CRON_TOKEN env var
- [ ] Enable HTTPS (free Let's Encrypt in cPanel)
- [ ] Restrict file permissions: `chmod 600 data/data.json`
- [ ] Restrict `data/` directory from web access (it's outside `public/` so safe)
- [ ] Set `Cookie Secure` if HTTPS — edit server.js cookie options
- [ ] Add rate limiting (express-rate-limit) if exposing publicly

## 8. Admin Panel

Once logged in as admin, visit `/admin/` to access:

- **Dashboard** — live stats, GGR, recent activity
- **Users** — search, edit balance, ban, reset password, delete
- **Transactions** — approve / reject pending withdrawals
- **Games** — enable/disable, set min/max bet, mark as HOT
- **Game History** — filter bets by game and user
- **Win Go Control** — override the next round's winning number
- **Settings** — site-wide config (starting balance, min deposit, auto-approve, etc.)

## 9. What this app DOES NOT do

- No real UPI / USDT payment integration
- No KYC, AML, or compliance flows
- No two-factor auth
- No anti-fraud / device fingerprinting
- No license-grade RNG audit trail

If you need any of the above, this is the wrong starting point — engage a
licensed gaming platform vendor with a proper compliance team.
