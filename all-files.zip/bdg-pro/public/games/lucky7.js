// Lucky 7 — above/below/equal to 7 on 2-dice sum
(function(){
  const root = document.getElementById('root');
  let pick = 'above';
  root.innerHTML = `
    ${BDG.gameHeader('Lucky 7')}
    <div class="panel">
      <div class="versus">
        <div class="side"><div class="label">DICE 1</div><div id="d1" class="dice3d">?</div></div>
        <div class="vs">+</div>
        <div class="side"><div class="label">DICE 2</div><div id="d2" class="dice3d">?</div></div>
      </div>
      <div style="text-align:center;font-size:24px;font-weight:900;color:var(--gold)">Sum: <span id="sum">—</span></div>
      <div class="row" style="margin-top:14px">
        <button id="below" class="btn green">Below 7 ×2</button>
        <button id="seven" class="btn violet">Lucky 7 ×5</button>
        <button id="above" class="btn red">Above 7 ×2</button>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="roll" class="btn" style="width:100%">Roll Dice</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();
  function setPick(p){
    pick = p;
    document.getElementById('above').className = 'btn ' + (p==='above'?'red':'ghost');
    document.getElementById('below').className = 'btn ' + (p==='below'?'green':'ghost');
    document.getElementById('seven').className = 'btn ' + (p==='seven'?'violet':'ghost');
  }
  document.getElementById('above').addEventListener('click', ()=>setPick('above'));
  document.getElementById('below').addEventListener('click', ()=>setPick('below'));
  document.getElementById('seven').addEventListener('click', ()=>setPick('seven'));
  setPick('above');

  document.getElementById('roll').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const d1 = 1+Math.floor(Math.random()*6);
    const d2 = 1+Math.floor(Math.random()*6);
    const sum = d1+d2;
    const e1 = document.getElementById('d1'), e2 = document.getElementById('d2');
    e1.textContent='?'; e2.textContent='?';
    e1.style.animation='none'; e2.style.animation='none';
    void e1.offsetWidth; void e2.offsetWidth;
    e1.style.animation='rolldice .6s ease'; e2.style.animation='rolldice .6s ease';
    setTimeout(()=>{
      e1.textContent = d1; e2.textContent = d2;
      document.getElementById('sum').textContent = sum;
      let payout = 0;
      if (pick==='above' && sum>7) payout = stake*2;
      else if (pick==='below' && sum<7) payout = stake*2;
      else if (pick==='seven' && sum===7) payout = stake*5;
      BDG.settle({game:'Lucky 7', stake, payout, result:`${d1}+${d2}=${sum}`});
      const el = document.getElementById('result');
      const win = payout>0;
      el.className='result '+(win?'win':'lose');
      el.textContent = win?`🎉 ${sum} — Won ₹${(payout-stake).toFixed(2)}`:`${sum} — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }, 600);
  });
})();
