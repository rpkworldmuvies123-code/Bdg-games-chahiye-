// Teen Patti — simplified showdown: 3-card hand ranking, pick player or dealer
(function(){
  const root = document.getElementById('root');
  const SUITS=['♠','♥','♦','♣'], RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  let pick = 'P';

  function rand(deck){ return deck.pop(); }
  function makeDeck(){
    const d=[];
    for (const s of SUITS) for (let i=0;i<RANKS.length;i++) d.push({r:i,s,name:RANKS[i],suit:s,red:s==='♥'||s==='♦'});
    return d.sort(()=>Math.random()-.5);
  }
  // Hand ranks: trail(6)>pure seq(5)>seq(4)>flush(3)>pair(2)>high(1)
  function rank(h){
    const ranks = h.map(c=>c.r).sort((a,b)=>a-b);
    const suits = h.map(c=>c.s);
    const flush = suits[0]===suits[1] && suits[1]===suits[2];
    const seq = (ranks[1]-ranks[0]===1 && ranks[2]-ranks[1]===1) || (ranks[0]===0 && ranks[1]===1 && ranks[2]===12); // A23
    const trail = ranks[0]===ranks[1] && ranks[1]===ranks[2];
    const pair = ranks[0]===ranks[1] || ranks[1]===ranks[2];
    if (trail) return [6, ranks[2]];
    if (flush && seq) return [5, ranks[2]];
    if (seq) return [4, ranks[2]];
    if (flush) return [3, ranks[2], ranks[1], ranks[0]];
    if (pair){
      const pr = ranks[0]===ranks[1] ? ranks[0] : ranks[1];
      const kicker = ranks[0]===ranks[1] ? ranks[2] : ranks[0];
      return [2, pr, kicker];
    }
    return [1, ranks[2], ranks[1], ranks[0]];
  }
  function cmp(a,b){ for (let i=0;i<Math.max(a.length,b.length);i++){ const x=a[i]||0,y=b[i]||0; if (x!==y) return x-y;} return 0; }
  const rankName = {6:'Trail',5:'Pure Sequence',4:'Sequence',3:'Color',2:'Pair',1:'High Card'};

  root.innerHTML = `
    ${BDG.gameHeader('Teen Patti')}
    <div class="panel">
      <div class="versus">
        <div class="side"><div class="label" style="color:#3cc7ff">PLAYER</div><div id="pHand" style="display:flex;gap:4px;justify-content:center"></div><div id="pRank" style="margin-top:6px;color:var(--gold);font-size:12px;font-weight:700"></div></div>
        <div class="vs">VS</div>
        <div class="side"><div class="label" style="color:#ff3b6e">DEALER</div><div id="dHand" style="display:flex;gap:4px;justify-content:center"></div><div id="dRank" style="margin-top:6px;color:var(--gold);font-size:12px;font-weight:700"></div></div>
      </div>
      <div class="row">
        <button id="pBtn" class="btn green">Player ×1.95</button>
        <button id="tieBtn" class="btn violet">Tie ×25</button>
        <button id="dBtn" class="btn red">Dealer ×1.95</button>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="deal" class="btn" style="width:100%">Deal</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();
  function setPick(p){
    pick = p;
    document.getElementById('pBtn').className = 'btn ' + (p==='P'?'green':'ghost');
    document.getElementById('dBtn').className = 'btn ' + (p==='D'?'red':'ghost');
    document.getElementById('tieBtn').className = 'btn ' + (p==='X'?'violet':'ghost');
  }
  document.getElementById('pBtn').addEventListener('click', ()=>setPick('P'));
  document.getElementById('dBtn').addEventListener('click', ()=>setPick('D'));
  document.getElementById('tieBtn').addEventListener('click', ()=>setPick('X'));

  function smallCard(c){
    return `<div class="card-3d ${c.red?'red':''}" style="width:50px;height:72px;font-size:18px">${c.name}<br/><span style="font-size:12px">${c.suit}</span></div>`;
  }

  document.getElementById('deal').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const deck = makeDeck();
    const p = [rand(deck),rand(deck),rand(deck)];
    const d = [rand(deck),rand(deck),rand(deck)];
    document.getElementById('pHand').innerHTML = p.map(smallCard).join('');
    document.getElementById('dHand').innerHTML = d.map(smallCard).join('');
    const pr = rank(p), dr = rank(d);
    document.getElementById('pRank').textContent = rankName[pr[0]];
    document.getElementById('dRank').textContent = rankName[dr[0]];
    const r = cmp(pr,dr);
    const winner = r>0?'P':r<0?'D':'X';
    let payout = 0;
    if (winner===pick) payout = stake * (pick==='X'?25:1.95);
    BDG.settle({game:'Teen Patti', stake, payout, result:`${winner} wins (${rankName[Math.max(pr[0],dr[0])]})`});
    const el = document.getElementById('result');
    const win = payout>0;
    el.className='result '+(win?'win':'lose');
    el.textContent = win?`🎉 ${winner==='P'?'Player':winner==='D'?'Dealer':'Tie'} wins — Won ₹${(payout-stake).toFixed(2)}`:`${winner==='P'?'Player':winner==='D'?'Dealer':'Tie'} wins — Lost ₹${stake}`;
    if (win) BDG.confetti();
  });
})();
