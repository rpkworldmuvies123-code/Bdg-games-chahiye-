// Blackjack — simplified, dealer hits to 17
(function(){
  const root = document.getElementById('root');
  const SUITS=['♠','♥','♦','♣'], RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
  let deck=[], me=[], dlr=[], stake=0, inGame=false, done=false;

  function newDeck(){
    deck = [];
    for (const s of SUITS) for (const r of RANKS) deck.push({r,s,name:r,suit:s,red:s==='♥'||s==='♦'});
    deck.sort(()=>Math.random()-.5);
  }
  function score(hand){
    let s=0, a=0;
    for (const c of hand){
      if (c.r==='A'){ s+=11; a++; }
      else if (['J','Q','K'].includes(c.r)) s+=10;
      else s+=Number(c.r);
    }
    while (s>21 && a>0){ s-=10; a--; }
    return s;
  }
  function cardHTML(c, hidden){
    if (hidden) return `<div class="card-3d back">?</div>`;
    return `<div class="card-3d ${c.red?'red':''}">${c.name}<br/><span style="font-size:18px">${c.suit}</span></div>`;
  }

  root.innerHTML = `
    ${BDG.gameHeader('Blackjack')}
    <div class="panel">
      <div style="color:var(--muted);font-size:12px">Dealer (<span id="dScore">0</span>)</div>
      <div id="dHand" style="display:flex;gap:6px;margin-top:6px;min-height:112px"></div>
      <hr style="margin:14px 0;border-color:rgba(255,255,255,.06)" />
      <div style="color:var(--muted);font-size:12px">You (<span id="mScore">0</span>)</div>
      <div id="mHand" style="display:flex;gap:6px;margin-top:6px;min-height:112px"></div>
    </div>
    ${BDG.stakeControls(50)}
    <div class="row">
      <button id="deal" class="btn green">Deal</button>
      <button id="hit" class="btn" disabled>Hit</button>
      <button id="stand" class="btn ghost" disabled>Stand</button>
    </div>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function render(reveal=false){
    document.getElementById('mHand').innerHTML = me.map(c=>cardHTML(c,false)).join('');
    document.getElementById('dHand').innerHTML = dlr.map((c,i)=>cardHTML(c, !reveal && i===1)).join('');
    document.getElementById('mScore').textContent = score(me);
    document.getElementById('dScore').textContent = reveal ? score(dlr) : (dlr[0]?score([dlr[0]]):0);
  }

  document.getElementById('deal').addEventListener('click', ()=>{
    stake = BDG.getStake(); if (!stake) return;
    BDG.settle({game:'Blackjack', stake, payout:0, result:'deal'}).then(()=>{
      newDeck(); me=[deck.pop(),deck.pop()]; dlr=[deck.pop(),deck.pop()]; inGame=true; done=false;
      render(false);
      const ms = score(me);
      document.getElementById('hit').disabled=false; document.getElementById('stand').disabled=false;
      document.getElementById('deal').disabled=true;
      if (ms===21){ stand(); }
    });
  });
  document.getElementById('hit').addEventListener('click', ()=>{
    if (!inGame) return;
    me.push(deck.pop()); render(false);
    if (score(me) > 21){ finish(); }
  });
  function stand(){
    while (score(dlr) < 17) dlr.push(deck.pop());
    finish();
  }
  document.getElementById('stand').addEventListener('click', stand);
  function finish(){
    inGame = false; done = true;
    render(true);
    const ms = score(me), ds = score(dlr);
    let payout = 0, msg='';
    if (ms>21){ msg = `Bust ${ms}`; }
    else if (ds>21){ payout = stake*2; msg = `Dealer bust ${ds}`; }
    else if (ms===ds){ payout = stake; msg = `Push ${ms}`; }
    else if (ms===21 && me.length===2){ payout = stake*2.5; msg = `Blackjack!`; }
    else if (ms>ds){ payout = stake*2; msg = `${ms} vs ${ds}`; }
    else { msg = `${ms} vs ${ds}`; }
    BDG.settle({game:'Blackjack', stake:0, payout, result:msg});
    const el = document.getElementById('result');
    el.className='result '+(payout>stake?'win':payout===stake?'':'lose');
    el.textContent = (payout>stake?`🎉 Won ₹${(payout-stake).toFixed(2)} — `:payout===stake?`Push — `:`Lost ₹${stake} — `)+msg;
    if (payout > stake) BDG.confetti();
    document.getElementById('hit').disabled=true; document.getElementById('stand').disabled=true;
    document.getElementById('deal').disabled=false;
  }
})();
