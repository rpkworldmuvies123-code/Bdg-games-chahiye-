// Scratch Card — reveal 9 cells, match 3 of a kind
(function(){
  const root = document.getElementById('root');
  const ICONS = ['💎','🪙','🍀','⭐','🍒','🎁'];
  const PAYS = {'💎':10,'🪙':5,'🍀':4,'⭐':3,'🍒':2,'🎁':2};
  let cells = [], revealed = [], inGame = false, stake = 0;

  root.innerHTML = `
    ${BDG.gameHeader('Scratch Card')}
    <div class="panel">
      <div class="scratch-grid" id="grid"></div>
      <div style="text-align:center;color:var(--muted);font-size:12px">Reveal all 9 — match 3 in a row, column, or diagonal to win!</div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="buy" class="btn" style="width:100%">Buy Card</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function render(){
    const g = document.getElementById('grid');
    g.innerHTML='';
    for (let i=0;i<9;i++){
      const d = document.createElement('div');
      d.className = 'scratch-cell' + (revealed[i]?' revealed':'');
      d.textContent = revealed[i] ? cells[i] : '?';
      d.addEventListener('click', ()=>{ if (inGame && !revealed[i]){ revealed[i]=true; render(); checkDone(); }});
      g.appendChild(d);
    }
  }
  function checkDone(){
    if (revealed.filter(Boolean).length === 9){
      // Check lines: rows, cols, diagonals
      const lines = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6],
      ];
      let mult = 0, winIcon = null;
      for (const ln of lines){
        if (cells[ln[0]] && cells[ln[0]]===cells[ln[1]] && cells[ln[1]]===cells[ln[2]]){
          const m = PAYS[cells[ln[0]]]||1;
          if (m > mult){ mult = m; winIcon = cells[ln[0]]; }
        }
      }
      const payout = stake*mult;
      BDG.settle({game:'Scratch', stake:0, payout, result: winIcon?`3× ${winIcon}`:'no match'});
      const el = document.getElementById('result');
      const win = payout > 0;
      el.className='result '+(win?'win':'lose');
      el.textContent = win?`🎉 3× ${winIcon} — Won ₹${payout.toFixed(2)}`:`No match — Lost ₹${stake}`;
      if (win) BDG.confetti();
      inGame = false;
    }
  }
  document.getElementById('buy').addEventListener('click', ()=>{
    stake = BDG.getStake(); if (!stake) return;
    BDG.settle({game:'Scratch', stake, payout:0, result:'card bought'}).then(()=>{
      cells = Array(9).fill(0).map(()=>ICONS[Math.floor(Math.random()*ICONS.length)]);
      revealed = Array(9).fill(false);
      inGame = true;
      render();
    });
  });
  render();
})();
