// Dragon vs Tiger — highest card wins
(function(){
  const root = document.getElementById('root');
  const SUITS=['♠','♥','♦','♣'], RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  let pick = 'D';
  function rand(){ const r=Math.floor(Math.random()*13), s=Math.floor(Math.random()*4); return {r,s,name:RANKS[r],suit:SUITS[s],red:s>=1&&s<=2}; }

  root.innerHTML = `
    ${BDG.gameHeader('Dragon vs Tiger')}
    <div class="panel">
      <div class="versus">
        <div class="side">
          <div class="label" style="color:#ff3b6e">🐉 Dragon</div>
          <div id="dCard" class="card-3d back" style="margin:0 auto">?</div>
        </div>
        <div class="vs">VS</div>
        <div class="side">
          <div class="label" style="color:#ffd166">🐅 Tiger</div>
          <div id="tCard" class="card-3d back" style="margin:0 auto">?</div>
        </div>
      </div>
      <div class="row">
        <button id="dBtn" class="btn red">Dragon ×1.95</button>
        <button id="tieBtn" class="btn violet">Tie ×8</button>
        <button id="tBtn" class="btn ghost">Tiger ×1.95</button>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="deal" class="btn" style="width:100%">Deal</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function setPick(p){
    pick = p;
    document.getElementById('dBtn').className = 'btn ' + (p==='D'?'red':'ghost');
    document.getElementById('tBtn').className = 'btn ' + (p==='T'?'red':'ghost');
    document.getElementById('tieBtn').className = 'btn ' + (p==='X'?'violet':'ghost');
  }
  document.getElementById('dBtn').addEventListener('click', ()=>setPick('D'));
  document.getElementById('tBtn').addEventListener('click', ()=>setPick('T'));
  document.getElementById('tieBtn').addEventListener('click', ()=>setPick('X'));

  document.getElementById('deal').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const d = rand(), t = rand();
    const dEl = document.getElementById('dCard'), tEl = document.getElementById('tCard');
    dEl.className = 'card-3d back'; tEl.className='card-3d back';
    dEl.innerHTML='?'; tEl.innerHTML='?';
    setTimeout(()=>{
      dEl.className = 'card-3d '+(d.red?'red':''); dEl.innerHTML = `${d.name}<br/><span style="font-size:18px">${d.suit}</span>`;
      tEl.className = 'card-3d '+(t.red?'red':''); tEl.innerHTML = `${t.name}<br/><span style="font-size:18px">${t.suit}</span>`;
      const result = d.r>t.r?'D':d.r<t.r?'T':'X';
      let payout = 0;
      if (result===pick) payout = stake * (pick==='X'?8:1.95);
      BDG.settle({game:'Dragon Tiger', stake, payout, result});
      const el = document.getElementById('result');
      const win = payout>0;
      el.className='result '+(win?'win':'lose');
      const winner = result==='D'?'Dragon':result==='T'?'Tiger':'Tie';
      el.textContent = win?`🎉 ${winner} — Won ₹${(payout-stake).toFixed(2)}`:`${winner} — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }, 600);
  });
})();
