// Sic Bo — 3 dice, bet on small/big/specific
(function(){
  const root = document.getElementById('root');
  let pick = null;

  root.innerHTML = `
    ${BDG.gameHeader('Sic Bo')}
    <div class="panel">
      <div class="versus">
        <div id="d1" class="dice3d">?</div>
        <div id="d2" class="dice3d">?</div>
        <div id="d3" class="dice3d">?</div>
      </div>
      <div style="text-align:center;font-size:22px;font-weight:900;color:var(--gold)">Total: <span id="sum">—</span></div>
      <h3 style="margin-top:14px">Sum Bets</h3>
      <div class="row">
        <button class="btn green" data-pick='{"t":"size","v":"small"}'>Small 4-10 ×2</button>
        <button class="btn red" data-pick='{"t":"size","v":"big"}'>Big 11-17 ×2</button>
      </div>
      <h3 style="margin-top:10px">Exact Sum (×6)</h3>
      <div class="num-grid" style="grid-template-columns:repeat(8,1fr)">
        ${Array.from({length:15},(_,i)=>i+4).map(n=>`<div class="num-btn" style="background:#1f2a6b;font-size:13px" data-pick='{"t":"sum","v":${n}}'>${n}</div>`).join('')}
      </div>
      <h3 style="margin-top:10px">Triple Any (×24)</h3>
      <button class="btn violet" style="width:100%" data-pick='{"t":"triple","v":"any"}'>Any Triple ×24</button>
    </div>
    ${BDG.stakeControls(10)}
    <button id="roll" class="btn" style="width:100%">Roll Dice</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  root.querySelectorAll('[data-pick]').forEach(el=>el.addEventListener('click', ()=>{
    pick = JSON.parse(el.dataset.pick);
    root.querySelectorAll('[data-pick]').forEach(x=>x.style.outline='');
    el.style.outline = '3px solid #ffd166';
  }));

  document.getElementById('roll').addEventListener('click', ()=>{
    if (!pick) return BDG.toast('Place a bet','lose');
    const stake = BDG.getStake(); if (!stake) return;
    const d = [1,1,1].map(()=>1+Math.floor(Math.random()*6));
    const sum = d[0]+d[1]+d[2];
    ['d1','d2','d3'].forEach((id,i)=>{
      const e = document.getElementById(id);
      e.textContent='?'; e.style.animation='none'; void e.offsetWidth;
      e.style.animation='rolldice .6s ease';
      setTimeout(()=>e.textContent = d[i], 600);
    });
    setTimeout(()=>{
      document.getElementById('sum').textContent = sum;
      const triple = d[0]===d[1] && d[1]===d[2];
      let payout = 0;
      if (pick.t==='size' && !triple){
        if (pick.v==='small' && sum>=4 && sum<=10) payout = stake*2;
        if (pick.v==='big' && sum>=11 && sum<=17) payout = stake*2;
      }
      if (pick.t==='sum' && pick.v===sum) payout = stake*6;
      if (pick.t==='triple' && triple) payout = stake*24;
      BDG.settle({game:'Sic Bo', stake, payout, result:`${d.join('+')}=${sum}${triple?' TRIPLE':''}`});
      const el = document.getElementById('result');
      const win = payout>0;
      el.className='result '+(win?'win':'lose');
      el.textContent = win?`🎉 ${sum}${triple?' TRIPLE':''} — Won ₹${(payout-stake).toFixed(2)}`:`${sum} — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }, 700);
  });
})();
