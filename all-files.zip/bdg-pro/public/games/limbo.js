// Limbo — pick target multiplier
(function(){
  const root = document.getElementById('root');
  let target = 2.0;
  root.innerHTML = `
    ${BDG.gameHeader('Limbo')}
    <div class="panel">
      <div class="limbo-mult" id="mult">—×</div>
      <div class="row">
        <div>
          <label style="font-size:12px;color:var(--muted)">Target ×</label>
          <input id="target" class="input" type="number" min="1.01" max="1000" step="0.01" value="2" />
        </div>
        <div>
          <label style="font-size:12px;color:var(--muted)">Win chance</label>
          <input id="chance" class="input" readonly value="49.50%" />
        </div>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="goBtn" class="btn" style="width:100%">Bet</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();
  function refresh(){
    target = Math.max(1.01, +document.getElementById('target').value||2);
    const chance = (0.99/target*100).toFixed(2);
    document.getElementById('chance').value = chance+'%';
  }
  document.getElementById('target').addEventListener('input', refresh);
  refresh();
  document.getElementById('goBtn').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    // Roll 0..99.99 uniform, multiplier = 99/(100-roll), no min cap
    const roll = +(Math.random()*99.99).toFixed(2);
    const m = +(99/(100-roll)).toFixed(2);
    const el = document.getElementById('mult');
    let n = 1; const start = performance.now();
    const animate = ()=>{
      const t = (performance.now()-start)/800;
      if (t<1){ n = 1 + (m-1)*t; el.textContent = n.toFixed(2)+'×'; requestAnimationFrame(animate); }
      else { el.textContent = m.toFixed(2)+'×'; finish(); }
    };
    animate();
    function finish(){
      const win = m >= target;
      const payout = win ? +(stake*target).toFixed(2) : 0;
      BDG.settle({game:'Limbo', stake, payout, result:`crashed ${m}× (target ${target}×)`});
      const r = document.getElementById('result');
      r.className='result '+(win?'win':'lose');
      r.textContent = win?`🎉 ${m.toFixed(2)}× ≥ ${target}× — Won ₹${(payout-stake).toFixed(2)}`:`${m.toFixed(2)}× < ${target}× — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }
  });
})();
