// Wheel — spin and win
(function(){
  const root = document.getElementById('root');
  const SEGMENTS = [
    {m:2, c:'#22e08a'},{m:1.5, c:'#3cc7ff'},{m:0, c:'#1f2a6b'},{m:5, c:'#ffd166'},
    {m:1.5, c:'#3cc7ff'},{m:0, c:'#1f2a6b'},{m:2, c:'#22e08a'},{m:10, c:'#ff3b6e'},
    {m:0, c:'#1f2a6b'},{m:1.5, c:'#3cc7ff'},{m:2, c:'#22e08a'},{m:50, c:'#a06bff'},
  ];
  const N = SEGMENTS.length;
  const deg = 360 / N;
  let rotation = 0, spinning = false;

  // Build conic gradient
  const stops = SEGMENTS.map((s,i)=>`${s.c} ${i*deg}deg ${(i+1)*deg}deg`).join(', ');

  root.innerHTML = `
    ${BDG.gameHeader('Lucky Wheel')}
    <div class="panel">
      <div class="wheel-wrap">
        <div class="wheel-pointer"></div>
        <div class="wheel" id="wheel" style="background:conic-gradient(${stops})"></div>
      </div>
      <div id="labels" style="display:grid;grid-template-columns:repeat(6,1fr);gap:6px;margin-top:10px">
        ${SEGMENTS.map(s=>`<div class="chip" style="text-align:center;color:${s.c};font-weight:900">${s.m}×</div>`).join('')}
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="spin" class="btn" style="width:100%;font-size:16px;padding:14px">SPIN</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  document.getElementById('spin').addEventListener('click', ()=>{
    if (spinning) return;
    const stake = BDG.getStake(); if (!stake) return;
    spinning = true;
    const idx = Math.floor(Math.random()*N);
    const mult = SEGMENTS[idx].m;
    // The pointer is at the top (0deg). To land idx in front, we need rotation such that
    // (-rotation + 0) lands in [idx*deg, (idx+1)*deg]. Add many full turns.
    const target = 360*5 + (360 - (idx*deg + deg/2));
    rotation = target;
    const w = document.getElementById('wheel');
    w.style.transform = `rotate(${rotation}deg)`;
    setTimeout(()=>{
      const payout = +(stake*mult).toFixed(2);
      BDG.settle({game:'Wheel', stake, payout, result:`${mult}×`});
      const el = document.getElementById('result');
      el.className='result ' + (payout>stake?'win':payout===stake?'':'lose');
      el.textContent = payout>stake ? `🎉 Won ₹${(payout-stake).toFixed(2)} (${mult}×)` : payout===stake ? `Pushed (${mult}×)` : `Lost ₹${stake}`;
      if (payout > stake) BDG.confetti();
      spinning = false;
      // Reset wheel rotation after a beat
      setTimeout(()=>{ w.style.transition='none'; w.style.transform=`rotate(${rotation%360}deg)`; setTimeout(()=>w.style.transition='',50); }, 500);
    }, 4100);
  });
})();
