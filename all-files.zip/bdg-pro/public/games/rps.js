// Rock Paper Scissors
(function(){
  const root = document.getElementById('root');
  const M = {rock:'✊', paper:'✋', scissors:'✌️'};
  let pick = null;

  root.innerHTML = `
    ${BDG.gameHeader('Rock Paper Scissors')}
    <div class="panel">
      <div class="rps-vs">
        <div style="text-align:center"><div style="color:var(--muted);font-size:11px">YOU</div><div id="you">?</div></div>
        <div style="font-size:24px;color:var(--gold)">VS</div>
        <div style="text-align:center"><div style="color:var(--muted);font-size:11px">CPU</div><div id="cpu">?</div></div>
      </div>
      <div class="rps-grid">
        <div class="rps-btn" data-p="rock">✊</div>
        <div class="rps-btn" data-p="paper">✋</div>
        <div class="rps-btn" data-p="scissors">✌️</div>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="play" class="btn" style="width:100%">Play ×1.95</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  root.querySelectorAll('.rps-btn').forEach(el=>{
    el.addEventListener('click', ()=>{
      pick = el.dataset.p;
      root.querySelectorAll('.rps-btn').forEach(x=>x.style.outline='');
      el.style.outline = '3px solid #ffd166';
    });
  });

  document.getElementById('play').addEventListener('click', ()=>{
    if (!pick) return BDG.toast('Pick rock/paper/scissors','lose');
    const stake = BDG.getStake(); if (!stake) return;
    const choices = ['rock','paper','scissors'];
    const cpu = choices[Math.floor(Math.random()*3)];
    document.getElementById('you').textContent = M[pick];
    document.getElementById('cpu').textContent = M[cpu];
    const beats = {rock:'scissors',paper:'rock',scissors:'paper'};
    const win = beats[pick]===cpu;
    const tie = pick===cpu;
    const payout = win ? +(stake*1.95).toFixed(2) : tie ? stake : 0;
    BDG.settle({game:'RPS', stake, payout, result:`you ${pick} vs cpu ${cpu}`});
    const el = document.getElementById('result');
    el.className='result '+(win?'win':tie?'':'lose');
    el.textContent = win?`🎉 Won ₹${(payout-stake).toFixed(2)}`:tie?`Tie — push`:`Lost ₹${stake}`;
    if (win) BDG.confetti();
  });
})();
