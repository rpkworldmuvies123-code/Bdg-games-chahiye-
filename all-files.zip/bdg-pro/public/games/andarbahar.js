// Andar Bahar — pick which side joker card lands first
(function(){
  const root = document.getElementById('root');
  const SUITS=['♠','♥','♦','♣'], RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
  let side = 'A';

  function rand(){ const r=Math.floor(Math.random()*13), s=Math.floor(Math.random()*4); return {r,s,name:RANKS[r],suit:SUITS[s],red:s>=1&&s<=2}; }

  root.innerHTML = `
    ${BDG.gameHeader('Andar Bahar')}
    <div class="panel">
      <div style="text-align:center;color:var(--muted);font-size:13px">Joker</div>
      <div id="joker" style="display:flex;justify-content:center;margin:8px 0"></div>
      <div class="ab-table">
        <div id="andar" class="ab-side A picked"><div style="font-weight:900;letter-spacing:1px">ANDAR</div><div style="font-size:11px;color:var(--muted);margin-top:4px">×1.9</div><div id="andarStack" style="display:flex;flex-wrap:wrap;gap:2px;margin-top:6px;justify-content:center;min-height:40px"></div></div>
        <div style="font-size:18px;font-weight:900;color:var(--gold)">VS</div>
        <div id="bahar" class="ab-side B"><div style="font-weight:900;letter-spacing:1px">BAHAR</div><div style="font-size:11px;color:var(--muted);margin-top:4px">×2.0</div><div id="baharStack" style="display:flex;flex-wrap:wrap;gap:2px;margin-top:6px;justify-content:center;min-height:40px"></div></div>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="deal" class="btn" style="width:100%">Deal</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function pickSide(s){
    side = s;
    document.getElementById('andar').classList.toggle('picked', s==='A');
    document.getElementById('bahar').classList.toggle('picked', s==='B');
  }
  document.getElementById('andar').addEventListener('click', ()=>pickSide('A'));
  document.getElementById('bahar').addEventListener('click', ()=>pickSide('B'));

  function miniCard(c){
    return `<div style="width:18px;height:24px;background:#fff;color:${c.red?'#d61f4b':'#222'};border-radius:3px;display:grid;place-items:center;font-size:9px;font-weight:900">${c.name}${c.suit}</div>`;
  }

  document.getElementById('deal').addEventListener('click', async ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const joker = rand();
    document.getElementById('joker').innerHTML = `<div class="card-3d ${joker.red?'red':''}">${joker.name}<br/><span style="font-size:18px">${joker.suit}</span></div>`;
    const aS = document.getElementById('andarStack');
    const bS = document.getElementById('baharStack');
    aS.innerHTML=''; bS.innerHTML='';
    let landed = null, turn = 'A';
    for (let i=0;i<26;i++){
      await new Promise(res=>setTimeout(res, 250));
      const c = rand();
      (turn==='A'?aS:bS).insertAdjacentHTML('beforeend', miniCard(c));
      if (c.r===joker.r){ landed = turn; break; }
      turn = turn==='A'?'B':'A';
    }
    if (!landed) landed = turn;
    const win = landed === side;
    const mult = landed==='A' ? 1.9 : 2.0;
    const payout = win ? +(stake*mult).toFixed(2) : 0;
    BDG.settle({game:'Andar Bahar', stake, payout, result:`landed on ${landed}`});
    const el = document.getElementById('result');
    el.className='result '+(win?'win':'lose');
    el.textContent = win?`🎉 Landed on ${landed==='A'?'Andar':'Bahar'} — Won ₹${(payout-stake).toFixed(2)}`:`Landed on ${landed==='A'?'Andar':'Bahar'} — Lost ₹${stake}`;
    if (win) BDG.confetti();
  });
})();
