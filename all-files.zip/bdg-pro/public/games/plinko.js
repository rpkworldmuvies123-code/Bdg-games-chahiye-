// Plinko — drop a ball through pegs
(function(){
  const root = document.getElementById('root');
  const ROWS = 9;
  const PAYOUTS = [9, 3, 1.5, 1, 0.5, 1, 1.5, 3, 9, 0]; // 10 buckets (slight adjust)
  // We'll use 10 buckets: index 0..9
  const BUCKETS = [10, 4, 2, 1.2, 0.5, 0.5, 1.2, 2, 4, 10];
  const COLORS = ['#ff3b6e','#ff6e8c','#ffaf2a','#ffd166','#3fe39a','#3fe39a','#ffd166','#ffaf2a','#ff6e8c','#ff3b6e'];

  root.innerHTML = `
    ${BDG.gameHeader('Plinko')}
    <div class="panel">
      <div class="plinko-board" id="board"></div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="drop" class="btn" style="width:100%">Drop Ball</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function drawBoard(){
    const b = document.getElementById('board');
    const W = b.clientWidth, H = b.clientHeight - 30;
    b.innerHTML = '';
    for (let r=0;r<ROWS;r++){
      const pegs = r + 3;
      const y = 20 + (H-40) * r/(ROWS-1);
      for (let i=0;i<pegs;i++){
        const x = W/2 - (pegs-1)*14 + i*28;
        const p = document.createElement('div');
        p.className='plinko-peg';
        p.style.left = (x-3)+'px';
        p.style.top = (y-3)+'px';
        b.appendChild(p);
      }
    }
    // buckets
    const wrap = document.createElement('div');
    wrap.className = 'plinko-buckets';
    BUCKETS.forEach((m,i)=>{
      const d = document.createElement('div');
      d.className='plinko-bucket';
      d.style.background = COLORS[i];
      d.textContent = m+'×';
      d.style.color = (m>=4)?'#fff':'#3a1f00';
      wrap.appendChild(d);
    });
    b.appendChild(wrap);
  }

  document.getElementById('drop').addEventListener('click', async ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    // simulate path: each row left/right
    let col = 0;
    for (let r=0;r<ROWS;r++) col += Math.random()<0.5?0:1;
    // map 0..9 -> bucket
    const bucket = Math.max(0, Math.min(9, col));
    const mult = BUCKETS[bucket];
    // animate ball
    const board = document.getElementById('board');
    const W = board.clientWidth, H = board.clientHeight - 30;
    const ball = document.createElement('div');
    ball.className='plinko-ball';
    ball.style.left = (W/2 - 7)+'px';
    ball.style.top = '0px';
    board.appendChild(ball);
    let x = W/2, c = 0;
    for (let r=0;r<ROWS;r++){
      await new Promise(res=>setTimeout(res, 150));
      // bias path towards final col
      const want = col;
      if (c < want) { x += 14; c++; }
      else if (c > want) { x -= 14; c--; }
      else x += (Math.random()<0.5?-1:1) * 6;
      const y = 20 + (H-40) * (r+1)/ROWS;
      ball.style.left = (x-7)+'px';
      ball.style.top = (y-7)+'px';
    }
    await new Promise(res=>setTimeout(res, 200));
    // drop into bucket
    ball.style.top = (H+10)+'px';
    setTimeout(()=>ball.remove(), 400);

    const payout = +(stake * mult).toFixed(2);
    BDG.settle({game:'Plinko', stake, payout, result:`${mult}×`});
    const el = document.getElementById('result');
    el.className = 'result ' + (payout>stake?'win':payout===stake?'':'lose');
    el.textContent = (payout>stake?`🎉 Won `:payout===stake?`Pushed `:`Lost `) + `₹${Math.abs(payout-stake).toFixed(2)} (${mult}×)`;
    if (payout > stake) BDG.confetti();
  });

  setTimeout(drawBoard, 50);
  window.addEventListener('resize', drawBoard);
})();
