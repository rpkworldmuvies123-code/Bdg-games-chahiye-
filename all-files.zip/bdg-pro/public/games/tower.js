// Tower — climb 8 floors, 1 bomb in each row of 3
(function(){
  const root = document.getElementById('root');
  const FLOORS = 8;
  let floor = 0, layout = [], stake = 0, inGame = false, mult = 1;

  root.innerHTML = `
    ${BDG.gameHeader('Tower')}
    <div class="panel">
      <div id="tower"></div>
      <div id="info" class="result">Set stake & climb</div>
    </div>
    ${BDG.stakeControls(10)}
    <div class="row">
      <button id="start" class="btn green">Start</button>
      <button id="cash" class="btn" disabled>Cash Out</button>
    </div>
  `;
  BDG.bindStakeChips();

  function render(reveal=false){
    const t = document.getElementById('tower');
    t.innerHTML = '';
    for (let r=0;r<FLOORS;r++){
      const row = document.createElement('div');
      row.className = 'tower-row' + (r===floor?' active':'') + (r<floor?' active':'');
      for (let c=0;c<3;c++){
        const cell = document.createElement('div');
        cell.className = 'tower-cell';
        if (reveal || r<floor){
          if (layout[r]===c){ cell.classList.add('bomb'); cell.textContent='💣'; }
          else if (r<floor){ cell.classList.add('safe'); cell.textContent='💎'; }
        }
        if (r===floor && inGame){
          cell.addEventListener('click', ()=>pick(c));
        }
        row.appendChild(cell);
      }
      t.appendChild(row);
    }
  }

  function pick(c){
    if (!inGame) return;
    if (layout[floor]===c){
      BDG.settle({game:'Tower', stake:0, payout:0, result:`bomb floor ${floor+1}`});
      inGame = false;
      render(true);
      document.getElementById('info').className='result lose';
      document.getElementById('info').textContent = `💥 Bomb on floor ${floor+1} — Lost ₹${stake}`;
      document.getElementById('cash').disabled = true;
      document.getElementById('start').disabled = false;
    } else {
      floor++;
      mult = +(Math.pow(1.4, floor)).toFixed(2);
      document.getElementById('info').className='result';
      document.getElementById('info').textContent = `Floor ${floor}/${FLOORS} — ×${mult} → ₹${(stake*mult).toFixed(2)}`;
      document.getElementById('cash').disabled = false;
      if (floor>=FLOORS){
        const payout = +(stake*mult).toFixed(2);
        BDG.settle({game:'Tower', stake:0, payout, result:'top floor'});
        inGame = false;
        document.getElementById('info').className='result win';
        document.getElementById('info').textContent = `👑 Reached top! Won ₹${payout.toFixed(2)}`;
        BDG.confetti();
        document.getElementById('start').disabled = false;
        document.getElementById('cash').disabled = true;
      }
      render();
    }
  }
  document.getElementById('start').addEventListener('click', ()=>{
    stake = BDG.getStake(); if (!stake) return;
    BDG.settle({game:'Tower', stake, payout:0, result:'started'}).then(()=>{
      floor = 0; mult = 1; inGame = true;
      layout = Array(FLOORS).fill(0).map(()=>Math.floor(Math.random()*3));
      document.getElementById('info').className='result';
      document.getElementById('info').textContent = 'Pick a cell on the active floor';
      document.getElementById('start').disabled = true;
      document.getElementById('cash').disabled = true;
      render();
    });
  });
  document.getElementById('cash').addEventListener('click', ()=>{
    if (!inGame || floor===0) return;
    const payout = +(stake*mult).toFixed(2);
    BDG.settle({game:'Tower', stake:0, payout, result:`cashed floor ${floor}`});
    inGame = false;
    document.getElementById('info').className='result win';
    document.getElementById('info').textContent = `Cashed ₹${payout.toFixed(2)} (${mult}×)`;
    BDG.confetti();
    document.getElementById('start').disabled = false;
    document.getElementById('cash').disabled = true;
    render();
  });
  render();
})();
