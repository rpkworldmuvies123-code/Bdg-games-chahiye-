// Coin Flip — heads or tails
(function(){
  const root = document.getElementById('root');
  let pick = 'heads';

  root.innerHTML = `
    ${BDG.gameHeader('Coin Flip')}
    <div class="panel" style="text-align:center">
      <div class="coin3d" id="coin">₹</div>
      <div class="row" style="margin-top:14px">
        <button id="h" class="btn green">Heads ×1.95</button>
        <button id="t" class="btn ghost">Tails ×1.95</button>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="flip" class="btn" style="width:100%">Flip</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function setPick(p){
    pick = p;
    document.getElementById('h').className = 'btn ' + (p==='heads'?'green':'ghost');
    document.getElementById('t').className = 'btn ' + (p==='tails'?'green':'ghost');
  }
  document.getElementById('h').addEventListener('click', ()=>setPick('heads'));
  document.getElementById('t').addEventListener('click', ()=>setPick('tails'));

  document.getElementById('flip').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const coin = document.getElementById('coin');
    const outcome = Math.random()<0.5?'heads':'tails';
    coin.classList.add('flipping');
    setTimeout(()=>{
      coin.classList.remove('flipping');
      coin.textContent = outcome==='heads'?'₹':'★';
      const win = outcome===pick;
      const payout = win ? +(stake*1.95).toFixed(2) : 0;
      BDG.settle({game:'Coin Flip', stake, payout, result:outcome});
      const el = document.getElementById('result');
      el.className='result '+(win?'win':'lose');
      el.textContent = win?`${outcome.toUpperCase()} — Won ₹${(payout-stake).toFixed(2)}`:`${outcome.toUpperCase()} — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }, 1500);
  });
})();
