// Mini Roulette — 0..12 with red/black/green
(function(){
  const root = document.getElementById('root');
  // 0=green, 1,3,5,7,9,11=red, 2,4,6,8,10,12=black
  const reds = [1,3,5,7,9,11];
  const colorOf = n => n===0 ? 'green' : reds.includes(n) ? 'red' : 'black';
  let pick = null;

  root.innerHTML = `
    ${BDG.gameHeader('Mini Roulette')}
    <div class="panel">
      <div class="roulette-wheel" id="wheel"></div>
      <div id="ball" style="text-align:center;font-size:24px;margin-top:6px">—</div>
    </div>
    <div class="panel">
      <h3>Outside Bets</h3>
      <div class="row">
        <button class="btn red" data-pick='{"type":"color","val":"red"}'>Red ×2</button>
        <button class="btn ghost" style="background:#222" data-pick='{"type":"color","val":"black"}'>Black ×2</button>
        <button class="btn green" data-pick='{"type":"color","val":"green"}'>Green ×12</button>
      </div>
      <div class="row" style="margin-top:8px">
        <button class="btn ghost" data-pick='{"type":"parity","val":"odd"}'>Odd ×2</button>
        <button class="btn ghost" data-pick='{"type":"parity","val":"even"}'>Even ×2</button>
        <button class="btn ghost" data-pick='{"type":"half","val":"low"}'>1-6 ×2</button>
        <button class="btn ghost" data-pick='{"type":"half","val":"high"}'>7-12 ×2</button>
      </div>
      <h3 style="margin-top:14px">Straight Up ×12</h3>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">
        ${Array.from({length:13},(_,n)=>{
          const c = colorOf(n);
          const bg = c==='red'?'#d61f4b':c==='green'?'#1aa86a':'#222';
          return `<div class="num-btn" style="background:${bg};font-size:13px" data-pick='{"type":"num","val":${n}}'>${n}</div>`;
        }).join('')}
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="spin" class="btn" style="width:100%">SPIN</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  root.querySelectorAll('[data-pick]').forEach(el=>{
    el.addEventListener('click', ()=>{
      pick = JSON.parse(el.dataset.pick);
      root.querySelectorAll('[data-pick]').forEach(x=>x.style.outline='');
      el.style.outline = '3px solid #ffd166';
    });
  });

  document.getElementById('spin').addEventListener('click', ()=>{
    if (!pick) return BDG.toast('Place a bet','lose');
    const stake = BDG.getStake(); if (!stake) return;
    const n = Math.floor(Math.random()*13);
    const c = colorOf(n);
    const wheel = document.getElementById('wheel');
    const turns = 4 + Math.random()*2;
    wheel.style.transform = `rotate(${360*turns}deg)`;
    setTimeout(()=>{ wheel.style.transition='none'; wheel.style.transform='rotate(0)'; setTimeout(()=>wheel.style.transition='',50); }, 3200);
    setTimeout(()=>{
      document.getElementById('ball').textContent = `${n} ${c.toUpperCase()}`;
      let payout = 0;
      if (pick.type==='num' && pick.val===n) payout = stake*12;
      else if (pick.type==='color' && pick.val===c) payout = stake*(c==='green'?12:2);
      else if (pick.type==='parity' && n!==0){ if ((pick.val==='odd' && n%2===1)||(pick.val==='even' && n%2===0)) payout = stake*2; }
      else if (pick.type==='half' && n!==0){ if ((pick.val==='low' && n<=6)||(pick.val==='high' && n>=7)) payout = stake*2; }
      BDG.settle({game:'Roulette', stake, payout, result:`${n} ${c}`});
      const el = document.getElementById('result');
      const win = payout>0;
      el.className='result '+(win?'win':'lose');
      el.textContent = win?`🎉 ${n} ${c.toUpperCase()} — Won ₹${(payout-stake).toFixed(2)}`:`${n} ${c.toUpperCase()} — Lost ₹${stake}`;
      if (win) BDG.confetti();
    }, 3000);
  });
})();
