// BDG Slots — 3-reel slot machine with 81 ways feel
(function(){
  const root = document.getElementById('root');
  const SYMBOLS = ['🐙','🦀','🐡','💎','🪙','👑','🅰','🅺','🚀'];
  const PAYOUTS = { '👑':50, '💎':25, '🪙':15, '🐙':10, '🦀':8, '🐡':6, '🚀':5, '🅰':3, '🅺':3 };

  root.innerHTML = `
    ${BDG.gameHeader('BDG Slots · 81 Ways')}
    <div class="panel">
      <div class="slot-machine">
        <div class="slot-reels" id="reels">
          <div class="slot-reel"><div class="strip"><div class="sym">🎰</div></div></div>
          <div class="slot-reel"><div class="strip"><div class="sym">🎰</div></div></div>
          <div class="slot-reel"><div class="strip"><div class="sym">🎰</div></div></div>
        </div>
        <div style="text-align:center;color:var(--gold);font-weight:900;letter-spacing:2px;margin-top:10px">CLASSIC · 81 WAYS · BONUS</div>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="spin" class="btn" style="width:100%;font-size:18px;padding:16px">SPIN</button>
    <div id="result"></div>

    <div class="panel" style="margin-top:14px">
      <h3>Paytable</h3>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;font-size:13px">
        ${Object.entries(PAYOUTS).map(([s,p])=>`<div style="text-align:center;background:rgba(255,255,255,.05);padding:8px;border-radius:8px">${s} ×3 → ${p}×</div>`).join('')}
      </div>
    </div>
  `;
  BDG.bindStakeChips();

  function spinReel(reelEl, finalSym){
    const strip = reelEl.querySelector('.strip');
    let html = '';
    for (let i=0;i<20;i++){
      html += `<div class="sym">${SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)]}</div>`;
    }
    html += `<div class="sym">${finalSym}</div>`;
    strip.innerHTML = html;
    strip.style.transform = 'translateY(0)';
    strip.style.transition = 'none';
    // Force reflow then animate
    void strip.offsetWidth;
    strip.style.transition = 'transform 1.4s cubic-bezier(.2,.7,.2,1)';
    strip.style.transform = `translateY(-${20*140}px)`;
  }

  document.getElementById('spin').addEventListener('click', async ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const reels = document.querySelectorAll('.slot-reel');
    const symbols = [
      SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)],
      SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)],
      SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)],
    ];
    // 12% chance to force triple
    if (Math.random() < 0.12){
      const s = SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)];
      symbols[0]=symbols[1]=symbols[2]=s;
    }
    reels.forEach((r,i)=>setTimeout(()=>spinReel(r, symbols[i]), i*180));
    await new Promise(res=>setTimeout(res, 1800));
    // Calc payout
    let payout = 0, result='';
    if (symbols[0]===symbols[1] && symbols[1]===symbols[2]){
      payout = stake * (PAYOUTS[symbols[0]]||2);
      result = `triple ${symbols[0]}`;
    } else if (symbols[0]===symbols[1] || symbols[1]===symbols[2] || symbols[0]===symbols[2]){
      payout = stake * 1.5;
      result = `pair`;
    } else {
      result = `no win`;
    }
    BDG.settle({game:'Slots', stake, payout, result});
    const el = document.getElementById('result');
    el.className = 'result ' + (payout>stake?'win':payout===stake?'':'lose');
    el.textContent = payout>stake?`🎉 ${result.toUpperCase()} — Won ₹${(payout-stake).toFixed(2)}`:`${result.toUpperCase()} — Lost ₹${stake}`;
    if (payout > stake) BDG.confetti();
  });
})();
