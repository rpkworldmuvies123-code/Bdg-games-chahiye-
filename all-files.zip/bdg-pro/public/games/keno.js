// Keno — pick numbers, 10 drawn
(function(){
  const root = document.getElementById('root');
  const TOTAL = 40, PICK_MAX = 10, DRAW = 10;
  let picks = new Set();
  // payout table by (picks, hits)
  const TABLE = {
    1:[0,3], 2:[0,1,5], 3:[0,1,2,10], 4:[0,0,1,4,15], 5:[0,0,1,3,8,25],
    6:[0,0,1,2,5,20,50], 7:[0,0,1,2,4,10,30,100], 8:[0,0,1,2,3,8,20,80,200],
    9:[0,0,1,1,2,5,15,50,150,500], 10:[0,0,1,1,2,4,10,30,100,300,1000],
  };

  root.innerHTML = `
    ${BDG.gameHeader('Keno')}
    <div class="panel">
      <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--muted)">
        <span>Picked: <b id="count" style="color:#fff">0</b>/10</span>
        <span>Hits: <b id="hits" style="color:#fff">—</b></span>
      </div>
      <div class="keno-grid" id="grid"></div>
    </div>
    ${BDG.stakeControls(10)}
    <div class="row">
      <button id="clear" class="btn ghost">Clear</button>
      <button id="play" class="btn">Play</button>
    </div>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function render(drawn=new Set(), hits=new Set()){
    const g = document.getElementById('grid');
    g.innerHTML='';
    for (let n=1;n<=TOTAL;n++){
      const d = document.createElement('div');
      d.className='keno-cell';
      d.textContent = n;
      if (picks.has(n)) d.classList.add('selected');
      if (drawn.has(n)) d.classList.add('drawn');
      if (hits.has(n)) d.classList.add('hit');
      d.addEventListener('click', ()=>{
        if (picks.has(n)) picks.delete(n);
        else if (picks.size<PICK_MAX) picks.add(n);
        document.getElementById('count').textContent = picks.size;
        render();
      });
      g.appendChild(d);
    }
  }
  document.getElementById('clear').addEventListener('click', ()=>{ picks.clear(); document.getElementById('count').textContent=0; render(); });
  document.getElementById('play').addEventListener('click', ()=>{
    if (picks.size===0) return BDG.toast('Pick 1-10 numbers','lose');
    const stake = BDG.getStake(); if (!stake) return;
    // Draw 10 unique
    const pool = [...Array(TOTAL).keys()].map(i=>i+1).sort(()=>Math.random()-.5);
    const drawn = new Set(pool.slice(0, DRAW));
    const hits = new Set([...picks].filter(p=>drawn.has(p)));
    document.getElementById('hits').textContent = `${hits.size}/${picks.size}`;
    render(drawn, hits);
    const mult = (TABLE[picks.size] && TABLE[picks.size][hits.size]) || 0;
    const payout = stake * mult;
    BDG.settle({game:'Keno', stake, payout, result:`${hits.size}/${picks.size} hits`});
    const el = document.getElementById('result');
    el.className='result '+(payout>stake?'win':payout===stake?'':'lose');
    el.textContent = payout>stake?`🎉 ${hits.size} hits — Won ₹${(payout-stake).toFixed(2)} (${mult}×)`:`${hits.size} hits — Lost ₹${stake}`;
    if (payout > stake) BDG.confetti();
  });
  render();
})();
