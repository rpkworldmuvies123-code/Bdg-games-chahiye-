// Aviator — crash multiplier game
(function(){
  const root = document.getElementById('root');
  let mult = 1.0, crashAt = 0, raf = null, bet = null, startTs = 0;
  let state = 'waiting'; // waiting | flying | crashed

  root.innerHTML = `
    ${BDG.gameHeader('Aviator')}
    <div class="panel">
      <div class="aviator-screen" id="screen">
        <svg class="aviator-curve" id="curve" viewBox="0 0 400 260" preserveAspectRatio="none"></svg>
        <div class="aviator-mult" id="mult">1.00×</div>
        <div class="aviator-plane" id="plane">✈️</div>
      </div>
    </div>

    ${BDG.stakeControls(10)}
    <div class="row" style="gap:8px">
      <button id="placeBet" class="btn green">Place Bet</button>
      <button id="cashOut" class="btn red" disabled>Cash Out</button>
    </div>

    <div class="panel" style="margin-top:12px">
      <h3>Last Crashes</h3>
      <div id="hist" style="display:flex;gap:6px;flex-wrap:wrap"></div>
    </div>

    <div class="panel">
      <h3>Live Bets</h3>
      <div class="aviator-bets-list" id="live"></div>
    </div>
  `;
  BDG.bindStakeChips();

  const hist = [];
  function pushHist(x){
    hist.unshift(x);
    if (hist.length > 12) hist.pop();
    document.getElementById('hist').innerHTML = hist.map(v=>{
      const cls = v < 2 ? 'red' : v < 10 ? '' : 'win';
      const color = v < 2 ? '#ff3b6e' : v < 10 ? '#3cc7ff' : '#ffd166';
      return `<span class="chip" style="color:${color};font-weight:900">${v.toFixed(2)}×</span>`;
    }).join('');
  }

  const liveNames = ['p***1','m***2','r***3','k***4','s***5','v***6','j***7','a***8'];
  const liveBets = [];
  function spawnLive(){
    const n = liveNames[Math.floor(Math.random()*liveNames.length)];
    const stake = [10,50,100,200,500][Math.floor(Math.random()*5)];
    const target = +(1.2 + Math.random()*4).toFixed(2);
    liveBets.unshift({n, stake, target, cashed:null});
    if (liveBets.length > 8) liveBets.pop();
    renderLive();
  }
  function renderLive(){
    document.getElementById('live').innerHTML = liveBets.map(b=>{
      const cashed = b.cashed ? `<span style="color:#9bf2c5">${b.cashed.toFixed(2)}× +₹${(b.stake*b.cashed-b.stake).toFixed(0)}</span>` : '<span style="color:var(--muted)">…</span>';
      return `<div class="row"><span>${b.n}</span><span>₹${b.stake}</span>${cashed}</div>`;
    }).join('');
  }

  function newCrash(){
    // House-favored distribution
    const r = Math.random();
    return +(0.01 + 1/(1-r*0.99)).toFixed(2);
  }

  function startRound(){
    crashAt = newCrash();
    mult = 1.0;
    startTs = performance.now();
    state = 'flying';
    document.getElementById('mult').classList.remove('crashed');
    document.getElementById('cashOut').disabled = !bet;
    liveBets.forEach(b=>b.cashed=null);
    // Random spawn
    for(let i=0;i<4;i++) spawnLive();
    tick();
  }

  function tick(){
    if (state !== 'flying') return;
    const t = (performance.now() - startTs)/1000;
    mult = +(Math.pow(1.08, t*1.6)).toFixed(2);
    document.getElementById('mult').textContent = mult.toFixed(2) + '×';
    // Move plane along curve
    const screen = document.getElementById('screen');
    const W = screen.clientWidth, H = screen.clientHeight;
    const progress = Math.min(t/8, 1);
    const x = 10 + progress * (W*0.7);
    const y = H - 30 - Math.pow(progress, 1.5) * (H*0.65);
    const plane = document.getElementById('plane');
    plane.style.left = x + 'px';
    plane.style.bottom = (H - y - 18) + 'px';
    plane.style.transform = `rotate(${-15 - progress*15}deg)`;
    // Draw curve
    const path = `M 10 ${H-30} Q ${x*0.6} ${H-30} ${x} ${y}`;
    document.getElementById('curve').innerHTML =
      `<path d="${path}" stroke="#ff3b6e" stroke-width="3" fill="none"/>
       <path d="${path} L ${x} ${H-30} Z" fill="rgba(255,59,110,.18)"/>`;

    // Live bots cashout
    liveBets.forEach(b=>{
      if (!b.cashed && mult >= b.target){ b.cashed = mult; }
    });
    renderLive();

    if (mult >= crashAt){
      crash();
      return;
    }
    raf = requestAnimationFrame(tick);
  }

  function crash(){
    state = 'crashed';
    document.getElementById('mult').textContent = `FLEW AWAY ${crashAt.toFixed(2)}×`;
    document.getElementById('mult').classList.add('crashed');
    document.getElementById('cashOut').disabled = true;
    pushHist(crashAt);
    if (bet){
      BDG.settle({game:'Aviator', stake:bet.stake, payout:0, result:`crashed @ ${crashAt.toFixed(2)}×`});
      const el = ensureResult();
      el.className = 'result lose';
      el.textContent = `Crashed at ${crashAt.toFixed(2)}× · Lost ₹${bet.stake}`;
      bet = null;
    }
    setTimeout(startRound, 3000);
  }

  function ensureResult(){
    let el = document.getElementById('result');
    if (!el){ el = document.createElement('div'); el.id='result'; root.appendChild(el); }
    return el;
  }

  document.getElementById('placeBet').addEventListener('click', ()=>{
    if (state !== 'waiting' && state !== 'crashed'){
      // Queue for next round
      if (bet) return BDG.toast('Bet already placed','lose');
    }
    const s = BDG.getStake(); if (!s) return;
    bet = { stake: s };
    BDG.toast('Bet placed','win');
    document.getElementById('cashOut').disabled = (state !== 'flying');
  });

  document.getElementById('cashOut').addEventListener('click', ()=>{
    if (!bet || state !== 'flying') return;
    const payout = +(bet.stake * mult).toFixed(2);
    BDG.settle({game:'Aviator', stake:bet.stake, payout, result:`cashed @ ${mult.toFixed(2)}×`});
    const el = ensureResult();
    el.className = 'result win';
    el.textContent = `Cashed @ ${mult.toFixed(2)}× · +₹${(payout-bet.stake).toFixed(2)}`;
    if (mult >= 5) BDG.bigWin(payout - bet.stake); else BDG.confetti();
    bet = null;
    document.getElementById('cashOut').disabled = true;
  });

  startRound();
})();
