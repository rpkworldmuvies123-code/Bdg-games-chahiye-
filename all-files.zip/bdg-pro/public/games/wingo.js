// Win Go — color prediction, 60s rounds
(function(){
  const root = document.getElementById('root');
  let pick = null; // {type:'color'|'num'|'size', val}
  let stake = 10;
  let period = 0;
  let timer = null;

  root.innerHTML = `
    ${BDG.gameHeader('Win Go 1Min')}
    <div class="panel">
      <div class="wingo-period">Period <span id="wgPeriod">—</span></div>
      <div class="wingo-timer" id="wgTimer">00 : 00</div>
      <div class="wingo-balls" id="wgBalls"></div>
    </div>

    <div class="panel">
      <h3>Select Color</h3>
      <div class="color-btns">
        <button class="color-btn green" data-pick='{"type":"color","val":"green"}'>Green ×2</button>
        <button class="color-btn violet" data-pick='{"type":"color","val":"violet"}'>Violet ×4.5</button>
        <button class="color-btn red" data-pick='{"type":"color","val":"red"}'>Red ×2</button>
      </div>

      <h3 style="margin-top:14px">Select Number ×9</h3>
      <div class="num-grid">
        ${[0,1,2,3,4,5,6,7,8,9].map(n=>{
          const c = (n===0||n===5)?'violet':(n%2===0?'red':'green');
          const bg = c==='red'?'#d61f4b':c==='green'?'#0fa362':'linear-gradient(135deg,#7233d4 50%,#d61f4b 50%)';
          return `<div class="num-btn" style="background:${bg}" data-pick='{"type":"num","val":${n}}'>${n}</div>`;
        }).join('')}
      </div>

      <h3 style="margin-top:14px">Big / Small ×2</h3>
      <div class="bigsmall">
        <button class="btn red" data-pick='{"type":"size","val":"big"}'>Big (5-9)</button>
        <button class="btn green" data-pick='{"type":"size","val":"small"}'>Small (0-4)</button>
      </div>
    </div>

    ${BDG.stakeControls(10)}

    <button id="placeBet" class="btn" style="width:100%;font-size:16px;padding:14px">Place Bet</button>
    <div id="result"></div>

    <div class="panel" style="margin-top:14px">
      <h3>Recent Results</h3>
      <div id="recents" style="display:flex;gap:6px;flex-wrap:wrap"></div>
    </div>
  `;
  BDG.bindStakeChips();

  // Pick handler
  root.querySelectorAll('[data-pick]').forEach(el=>{
    el.addEventListener('click', ()=>{
      pick = JSON.parse(el.dataset.pick);
      root.querySelectorAll('[data-pick]').forEach(x=>x.style.outline='');
      el.style.outline = '3px solid #ffd166';
      BDG.toast(`Selected: ${pick.val}`);
    });
  });

  let pendingBet = null;
  document.getElementById('placeBet').addEventListener('click', ()=>{
    if (!pick) return BDG.toast('Pick a color, number, or big/small','lose');
    stake = BDG.getStake(); if (!stake) return;
    pendingBet = { pick, stake, period };
    BDG.toast(`Bet placed for period ${period}`,'win');
  });

  async function poll(){
    const r = await fetch('/api/wingo/state');
    const j = await r.json();
    document.getElementById('wgPeriod').textContent = j.period;
    const sec = Math.ceil(j.remaining/1000);
    const m = Math.floor(sec/60), s = sec%60;
    document.getElementById('wgTimer').textContent = `${String(m).padStart(2,'0')} : ${String(s).padStart(2,'0')}`;
    renderRecents(j.history);
    if (period && period !== j.period){
      // Round ended — settle previous round
      const draw = await fetch('/api/wingo/draw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({period})}).then(r=>r.json());
      if (pendingBet && pendingBet.period === period){
        settleBet(pendingBet, draw);
        pendingBet = null;
      }
    }
    period = j.period;
  }
  function renderRecents(hist){
    document.getElementById('recents').innerHTML = hist.map(h=>{
      const c = h.color.includes('violet') && h.color.length>1 ? 'violet' : h.color[0];
      return `<div class="wingo-ball ${c}">${h.number}</div>`;
    }).join('');
  }
  function settleBet(b, draw){
    let payout = 0;
    if (b.pick.type==='color'){
      if (draw.color.includes(b.pick.val)) payout = b.stake * (b.pick.val==='violet'?4.5:2);
    } else if (b.pick.type==='num'){
      if (draw.number === b.pick.val) payout = b.stake * 9;
    } else if (b.pick.type==='size'){
      const big = draw.number >= 5;
      if ((b.pick.val==='big' && big) || (b.pick.val==='small' && !big)) payout = b.stake * 2;
    }
    const win = payout > 0;
    BDG.settle({game:'Win Go', stake:b.stake, payout, result:`#${draw.number} ${draw.color.join('+')}`});
    const el = document.getElementById('result');
    el.className = 'result ' + (win?'win':'lose');
    el.innerHTML = win ? `🎉 Won ₹${(payout-b.stake).toFixed(2)} · Number ${draw.number}` : `Lost ₹${b.stake} · Number ${draw.number}`;
    if (win) BDG.confetti();
  }
  poll();
  timer = setInterval(poll, 1000);
  window.addEventListener('beforeunload', ()=>clearInterval(timer));
})();
