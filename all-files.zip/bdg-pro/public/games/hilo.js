// Hi-Lo — higher or lower
(function(){
  const root = document.getElementById('root');
  const SUITS=['♠','♥','♦','♣'], RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  let current = draw(), mult = 1, stake = 0, inGame = false;

  function draw(){
    const r = Math.floor(Math.random()*13);
    const s = Math.floor(Math.random()*4);
    return { r, s, name: RANKS[r], suit: SUITS[s], red: s>=1 && s<=2 };
  }

  root.innerHTML = `
    ${BDG.gameHeader('Hi-Lo')}
    <div class="panel" style="text-align:center">
      <div style="display:flex;justify-content:center;gap:18px;margin:14px 0">
        <div id="card" class="card-3d ${current.red?'red':''}">${current.name}<br/><span style="font-size:18px">${current.suit}</span></div>
      </div>
      <div id="mult" style="font-size:20px;font-weight:800;color:var(--gold)">Current ×1.00</div>
      <div class="row" style="margin-top:14px">
        <button id="hi" class="btn green">Higher ▲</button>
        <button id="lo" class="btn red">Lower ▼</button>
      </div>
      <button id="cash" class="btn" style="width:100%;margin-top:10px" disabled>Cash Out</button>
    </div>
    ${BDG.stakeControls(10)}
    <button id="startBtn" class="btn green" style="width:100%">Start</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function render(){
    const c = document.getElementById('card');
    c.className = 'card-3d ' + (current.red?'red':'');
    c.innerHTML = `${current.name}<br/><span style="font-size:18px">${current.suit}</span>`;
    document.getElementById('mult').textContent = `Current ×${mult.toFixed(2)}`;
  }
  function pick(higher){
    if (!inGame) return;
    const next = draw();
    const ok = higher ? next.r > current.r : next.r < current.r;
    current = next; render();
    if (!ok){
      BDG.settle({game:'Hi-Lo', stake:0, payout:0, result:`busted at ${current.name}${current.suit}`});
      const el = document.getElementById('result');
      el.className='result lose'; el.textContent = `Bust on ${current.name}${current.suit} — Lost ₹${stake}`;
      end();
    } else {
      // multiplier: prob of higher = (12-r)/12 (ignoring ties)
      const p = higher ? (12-current.r)/12 : current.r/12;
      mult = +(mult / (Math.max(0.05, p)) * 0.97).toFixed(2);
      document.getElementById('mult').textContent = `Current ×${mult.toFixed(2)} → ₹${(stake*mult).toFixed(2)}`;
      document.getElementById('cash').disabled = false;
    }
  }
  function end(){
    inGame = false;
    document.getElementById('hi').disabled = true;
    document.getElementById('lo').disabled = true;
    document.getElementById('cash').disabled = true;
    document.getElementById('startBtn').disabled = false;
  }
  document.getElementById('hi').addEventListener('click', ()=>pick(true));
  document.getElementById('lo').addEventListener('click', ()=>pick(false));
  document.getElementById('cash').addEventListener('click', ()=>{
    if (!inGame) return;
    const payout = +(stake*mult).toFixed(2);
    BDG.settle({game:'Hi-Lo', stake:0, payout, result:`cashed ${mult}×`});
    const el = document.getElementById('result'); el.className='result win';
    el.textContent = `Cashed ₹${payout.toFixed(2)} (${mult.toFixed(2)}×)`;
    BDG.confetti(); end();
  });
  document.getElementById('startBtn').addEventListener('click', ()=>{
    stake = BDG.getStake(); if (!stake) return;
    BDG.settle({game:'Hi-Lo', stake, payout:0, result:'started'}).then(()=>{
      mult = 1; inGame = true; current = draw(); render();
      document.getElementById('hi').disabled = false;
      document.getElementById('lo').disabled = false;
      document.getElementById('startBtn').disabled = true;
    });
  });
  render();
  document.getElementById('hi').disabled = true;
  document.getElementById('lo').disabled = true;
})();
