// Dice — roll over/under
(function(){
  const root = document.getElementById('root');
  let target = 50, over = true;

  root.innerHTML = `
    ${BDG.gameHeader('Dice')}
    <div class="panel">
      <div class="dice-roll" id="roll">—</div>
      <div class="dice-bar" id="bar"><div class="dice-thumb" id="thumb"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted)">
        <span>0</span><span>100</span>
      </div>
      <div class="row" style="margin-top:14px">
        <div>
          <label style="font-size:12px;color:var(--muted)">Target</label>
          <input id="target" class="input" type="number" min="2" max="98" value="50" />
        </div>
        <div>
          <label style="font-size:12px;color:var(--muted)">Direction</label>
          <div class="row" style="gap:6px">
            <button id="overBtn" class="btn green">Roll Over</button>
            <button id="underBtn" class="btn ghost">Roll Under</button>
          </div>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:10px;font-size:13px;color:var(--muted)">
        <span>Win chance: <b id="chance" style="color:#fff">50.0%</b></span>
        <span>Multiplier: <b id="mult" style="color:#fff">1.94×</b></span>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <button id="rollBtn" class="btn" style="width:100%">Roll</button>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function refresh(){
    target = Math.max(2, Math.min(98, +document.getElementById('target').value||50));
    const chance = over ? (100-target) : target;
    const mult = +(0.97 * 100 / chance).toFixed(2);
    document.getElementById('chance').textContent = chance.toFixed(1) + '%';
    document.getElementById('mult').textContent = mult.toFixed(2) + '×';
    const t = document.getElementById('thumb');
    t.style.left = `calc(${target}% - 2px)`;
    const bar = document.getElementById('bar');
    bar.style.background = over
      ? `linear-gradient(90deg,#d61f4b 0%,#d61f4b ${target}%,#1aa86a ${target}%,#1aa86a 100%)`
      : `linear-gradient(90deg,#1aa86a 0%,#1aa86a ${target}%,#d61f4b ${target}%,#d61f4b 100%)`;
  }
  document.getElementById('target').addEventListener('input', refresh);
  document.getElementById('overBtn').addEventListener('click', ()=>{
    over=true;
    document.getElementById('overBtn').classList.remove('ghost');
    document.getElementById('overBtn').classList.add('green');
    document.getElementById('underBtn').classList.add('ghost');
    document.getElementById('underBtn').classList.remove('green');
    refresh();
  });
  document.getElementById('underBtn').addEventListener('click', ()=>{
    over=false;
    document.getElementById('underBtn').classList.remove('ghost');
    document.getElementById('underBtn').classList.add('green');
    document.getElementById('overBtn').classList.add('ghost');
    document.getElementById('overBtn').classList.remove('green');
    refresh();
  });

  document.getElementById('rollBtn').addEventListener('click', ()=>{
    const stake = BDG.getStake(); if (!stake) return;
    const r = +(Math.random()*100).toFixed(2);
    const win = over ? r > target : r < target;
    const chance = over ? (100-target) : target;
    const mult = 0.97*100/chance;
    const payout = win ? +(stake*mult).toFixed(2) : 0;
    document.getElementById('roll').textContent = r.toFixed(2);
    BDG.settle({game:'Dice', stake, payout, result:`rolled ${r.toFixed(2)} ${over?'over':'under'} ${target}`});
    const el = document.getElementById('result');
    el.className='result ' + (win?'win':'lose');
    el.textContent = win ? `🎉 Won ₹${(payout-stake).toFixed(2)}` : `Lost ₹${stake}`;
    if (win) BDG.confetti();
  });
  refresh();
})();
