// Mines — reveal safe tiles, avoid mines
(function(){
  const root = document.getElementById('root');
  const SIZE = 25, MINES_OPTIONS = [3,5,7,10];
  let mines = 5, stake = 10, layout = [], revealed = [], inGame = false, picks = 0;

  root.innerHTML = `
    ${BDG.gameHeader('Mines')}
    <div class="panel">
      <div class="row">
        <div>
          <h3>Mines</h3>
          <div class="stake-row" id="mineCount">
            ${MINES_OPTIONS.map(m=>`<div class="chip ${m===5?'active':''}" data-mines="${m}">${m}</div>`).join('')}
          </div>
        </div>
      </div>
      <div class="mines-grid" id="grid"></div>
      <div class="result" id="info" style="margin-top:10px">Set stake and Start</div>
    </div>
    ${BDG.stakeControls(10)}
    <div class="row" style="gap:8px">
      <button id="startBtn" class="btn green">Start Game</button>
      <button id="cashBtn" class="btn" disabled>Cash Out</button>
    </div>
  `;
  BDG.bindStakeChips();

  document.getElementById('mineCount').addEventListener('click',(e)=>{
    if (e.target.dataset.mines){
      mines = +e.target.dataset.mines;
      document.querySelectorAll('#mineCount .chip').forEach(c=>c.classList.toggle('active', +c.dataset.mines===mines));
    }
  });

  function render(){
    const g = document.getElementById('grid');
    g.innerHTML = '';
    for (let i=0;i<SIZE;i++){
      const d = document.createElement('div');
      d.className = 'mine-cell';
      d.dataset.i = i;
      if (revealed[i]==='gem') { d.classList.add('revealed'); d.textContent='💎'; }
      else if (revealed[i]==='bomb') { d.classList.add('bomb'); d.textContent='💣'; }
      d.addEventListener('click', ()=>pick(i));
      g.appendChild(d);
    }
  }
  function mult(){
    // payout multiplier ≈ C(25,picks)/C(25-mines, picks) * 0.97
    const c = (n,k)=>{ let r=1; for(let i=0;i<k;i++) r = r*(n-i)/(i+1); return r; };
    return picks ? +((c(25,picks)/c(25-mines,picks))*0.97).toFixed(3) : 1;
  }
  function pick(i){
    if (!inGame) return;
    if (revealed[i]) return;
    if (layout[i]){
      revealed[i] = 'bomb';
      // reveal all bombs
      layout.forEach((v,j)=>{ if (v && !revealed[j]) revealed[j]='bomb'; });
      inGame = false;
      BDG.settle({game:'Mines', stake, payout:0, result:`hit bomb after ${picks} picks`});
      document.getElementById('info').className='result lose';
      document.getElementById('info').textContent = `💥 Boom! Lost ₹${stake}`;
      document.getElementById('startBtn').disabled = false;
      document.getElementById('cashBtn').disabled = true;
    } else {
      revealed[i] = 'gem';
      picks++;
      document.getElementById('info').className='result';
      document.getElementById('info').textContent = `Safe! Multiplier ${mult().toFixed(2)}× → ₹${(stake*mult()).toFixed(2)}`;
    }
    render();
  }
  document.getElementById('startBtn').addEventListener('click', ()=>{
    stake = BDG.getStake(); if (!stake) return;
    // Deduct stake upfront
    BDG.settle({game:'Mines', stake, payout:0, result:'started'}).then(()=>{
      layout = Array(SIZE).fill(false); revealed = Array(SIZE).fill(null); picks=0;
      const pos = [...Array(SIZE).keys()].sort(()=>Math.random()-.5).slice(0,mines);
      pos.forEach(p=>layout[p]=true);
      inGame = true;
      document.getElementById('startBtn').disabled = true;
      document.getElementById('cashBtn').disabled = false;
      document.getElementById('info').className='result';
      document.getElementById('info').textContent = 'Pick a tile';
      render();
    });
  });
  document.getElementById('cashBtn').addEventListener('click', ()=>{
    if (!inGame || picks===0) return BDG.toast('Pick at least one tile','lose');
    const payout = +(stake * mult()).toFixed(2);
    BDG.settle({game:'Mines', stake:0, payout, result:`cashed ${mult().toFixed(2)}× (${picks} picks)`});
    document.getElementById('info').className='result win';
    document.getElementById('info').textContent = `Cashed ₹${payout.toFixed(2)} (${mult().toFixed(2)}×)`;
    BDG.confetti();
    inGame = false;
    document.getElementById('startBtn').disabled = false;
    document.getElementById('cashBtn').disabled = true;
  });
  render();
})();
