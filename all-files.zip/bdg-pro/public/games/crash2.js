// Rocket Crash — simple instant-crash variant
(function(){
  const root = document.getElementById('root');
  let mult=1, target=2, running=false, raf=null, bet=null;
  root.innerHTML = `
    ${BDG.gameHeader('Rocket Crash')}
    <div class="panel">
      <div style="position:relative;height:240px;overflow:hidden;border-radius:14px;background:radial-gradient(circle at 50% 100%, rgba(255,59,110,.25), transparent 70%),#0a0d28;border:1px solid #1f2a6b">
        <div id="rocket" style="position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font-size:50px">🚀</div>
        <div id="mult" style="position:absolute;left:50%;top:42%;transform:translate(-50%,-50%);font-size:60px;font-weight:900;color:#fff">1.00×</div>
      </div>
      <div class="row" style="margin-top:10px">
        <div><label style="font-size:12px;color:var(--muted)">Auto Cashout ×</label><input id="ac" class="input" type="number" step="0.1" value="2"/></div>
      </div>
    </div>
    ${BDG.stakeControls(10)}
    <div class="row">
      <button id="bet" class="btn green">Bet</button>
      <button id="cash" class="btn red" disabled>Cash Out</button>
    </div>
    <div id="result"></div>
  `;
  BDG.bindStakeChips();

  function start(){
    target = +document.getElementById('ac').value || 2;
    mult = 1; running = true;
    document.getElementById('mult').style.color = '#fff';
    const startTs = performance.now();
    const crashAt = +(0.01 + 1/(1-Math.random()*0.99)).toFixed(2);
    function tick(){
      if (!running) return;
      const t=(performance.now()-startTs)/1000;
      mult = +(Math.pow(1.08,t*1.6)).toFixed(2);
      document.getElementById('mult').textContent = mult.toFixed(2)+'×';
      const r = document.getElementById('rocket');
      r.style.bottom = (10 + Math.min(t/8,1)*180)+'px';
      r.style.transform = `translateX(-50%) rotate(${-15-Math.min(t/8,1)*30}deg)`;
      if (bet && mult >= target){
        // auto cashout
        const payout = +(bet.stake*mult).toFixed(2);
        BDG.settle({game:'Rocket Crash', stake:bet.stake, payout, result:`auto ${mult}×`});
        const el=document.getElementById('result'); el.className='result win';
        el.textContent = `Auto-cashed @ ${mult.toFixed(2)}× — Won ₹${(payout-bet.stake).toFixed(2)}`;
        BDG.confetti(); bet=null; document.getElementById('cash').disabled=true;
      }
      if (mult >= crashAt){
        running = false;
        document.getElementById('mult').textContent = `CRASHED ${crashAt.toFixed(2)}×`;
        document.getElementById('mult').style.color = '#ff3b6e';
        if (bet){
          BDG.settle({game:'Rocket Crash', stake:bet.stake, payout:0, result:`crashed ${crashAt}×`});
          const el=document.getElementById('result'); el.className='result lose';
          el.textContent = `Crashed @ ${crashAt.toFixed(2)}× — Lost ₹${bet.stake}`;
          bet = null;
        }
        setTimeout(start, 2500);
        return;
      }
      raf = requestAnimationFrame(tick);
    }
    tick();
  }
  document.getElementById('bet').addEventListener('click', ()=>{
    if (bet) return BDG.toast('Bet already placed','lose');
    const s = BDG.getStake(); if (!s) return;
    bet = {stake:s};
    document.getElementById('cash').disabled = !running;
  });
  document.getElementById('cash').addEventListener('click', ()=>{
    if (!bet||!running) return;
    const payout = +(bet.stake*mult).toFixed(2);
    BDG.settle({game:'Rocket Crash', stake:bet.stake, payout, result:`cashed ${mult}×`});
    const el=document.getElementById('result'); el.className='result win';
    el.textContent = `Cashed @ ${mult.toFixed(2)}× — Won ₹${(payout-bet.stake).toFixed(2)}`;
    BDG.confetti(); bet=null;
    document.getElementById('cash').disabled=true;
  });
  start();
})();
