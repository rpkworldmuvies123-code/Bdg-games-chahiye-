// Shared client helpers — auth, wallet, settle, toast, confetti, animations
window.BDG = (() => {
  let bal = 0, user = null;

  async function me() {
    const r = await fetch('/api/me');
    const j = await r.json();
    user = j.user;
    if (user) bal = user.balance;
    paintBalance();
    paintUser();
    return user;
  }

  async function refreshWallet() {
    if (!user) await me();
    if (!user) return null;
    const r = await fetch('/api/wallet');
    if (r.status === 401){ user = null; return null; }
    const j = await r.json();
    bal = j.balance;
    paintBalance();
    return j;
  }

  function paintBalance() {
    document.querySelectorAll('[data-balance]').forEach(el => {
      el.textContent = '₹' + bal.toFixed(2);
    });
  }
  function paintUser() {
    document.querySelectorAll('[data-username]').forEach(el => {
      el.textContent = user ? user.username : 'Guest';
    });
  }
  function getBalance() { return bal; }
  function getUser() { return user; }

  function requireLogin() {
    if (!user) { location.href = '/login.html'; return false; }
    return true;
  }

  async function logout(){
    await fetch('/api/auth/logout',{method:'POST'});
    location.href = '/login.html';
  }

  async function settle({ game, stake, payout, result }) {
    const r = await fetch('/api/settle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ game, stake, payout, result }),
    });
    const j = await r.json();
    if (r.status === 401){ location.href='/login.html'; return j; }
    if (j.ok) { bal = j.balance; paintBalance(); }
    else if (j.error) toast(j.error,'lose');
    return j;
  }

  function toast(msg, kind = '') {
    const t = document.createElement('div');
    t.className = 'toast ' + kind;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2200);
  }

  function confetti() {
    const wrap = document.createElement('div');
    wrap.className = 'confetti';
    const colors = ['#ffd166', '#ff3b6e', '#22e08a', '#3cc7ff', '#a06bff'];
    for (let i = 0; i < 80; i++) {
      const s = document.createElement('span');
      s.style.left = Math.random() * 100 + 'vw';
      s.style.background = colors[Math.floor(Math.random() * colors.length)];
      s.style.animationDelay = (Math.random() * 0.4) + 's';
      s.style.animationDuration = (1 + Math.random()) + 's';
      wrap.appendChild(s);
    }
    document.body.appendChild(wrap);
    setTimeout(() => wrap.remove(), 2200);
  }

  // Big win celebration with stars and ₹ rain
  function bigWin(amount){
    confetti();
    const wrap = document.createElement('div');
    wrap.className = 'bigwin-overlay';
    wrap.innerHTML = `
      <div class="bigwin-card">
        <div class="bigwin-stars">${'⭐'.repeat(5)}</div>
        <div class="bigwin-title">BIG WIN!</div>
        <div class="bigwin-amount">+₹${amount.toFixed(2)}</div>
      </div>`;
    document.body.appendChild(wrap);
    setTimeout(()=>wrap.classList.add('show'), 10);
    setTimeout(()=>{ wrap.classList.remove('show'); setTimeout(()=>wrap.remove(),400); }, 2400);
  }

  // Loss shake on a target element
  function shake(el){
    if (!el) return;
    el.classList.add('shake');
    setTimeout(()=>el.classList.remove('shake'), 500);
  }

  function gameHeader(title) {
    return `<div class="game-header">
      <a class="back" href="/">←</a>
      <h2>${title}</h2>
      <div class="bal">💰 <span data-balance>₹0.00</span></div>
    </div>`;
  }

  function stakeControls(defaultAmt = 10) {
    return `<div class="panel">
      <h3>Bet Amount</h3>
      <div class="row">
        <input id="stake" class="input" type="number" value="${defaultAmt}" min="1" />
      </div>
      <div class="stake-row">
        ${[10,50,100,500,1000].map(v => `<div class="chip" data-stake="${v}">₹${v}</div>`).join('')}
      </div>
    </div>`;
  }

  function bindStakeChips() {
    document.querySelectorAll('[data-stake]').forEach(el => {
      el.addEventListener('click', () => {
        document.getElementById('stake').value = el.dataset.stake;
        document.querySelectorAll('[data-stake]').forEach(x => x.classList.remove('active'));
        el.classList.add('active');
      });
    });
  }

  function getStake() {
    const v = Number(document.getElementById('stake').value);
    if (!v || v <= 0) { toast('Enter a valid stake', 'lose'); return 0; }
    if (v > bal) { toast('Insufficient balance', 'lose'); return 0; }
    return v;
  }

  // Helper to show win/loss after a bet, with animations
  function showResult(elementId, won, amount, message) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.className = 'result ' + (won ? 'win pop' : amount === 0 ? '' : 'lose pop');
    el.textContent = message;
    if (won) {
      if (amount >= bal * 0.5 && amount > 100) bigWin(amount);
      else confetti();
    } else if (amount > 0) {
      shake(el);
    }
  }

  return { me, refreshWallet, paintBalance, getBalance, getUser, requireLogin, logout, settle, toast, confetti, bigWin, shake, gameHeader, stakeControls, bindStakeChips, getStake, showResult };
})();

document.addEventListener('DOMContentLoaded', async () => {
  if (!window.BDG) return;
  await window.BDG.me();
  // Redirect non-auth users away from game/wallet/history pages
  const protectedPaths = ['/game.html','/wallet.html','/history.html'];
  if (protectedPaths.some(p => location.pathname === p) && !window.BDG.getUser()) {
    location.href = '/login.html';
  }
  // Auto-animate any result panel — observer triggers shake on .result.lose,
  // pop on any change. Confetti is still triggered explicitly by each game.
  const seen = new WeakSet();
  const mo = new MutationObserver(muts => {
    for (const m of muts) {
      const t = m.target;
      if (!(t instanceof HTMLElement)) continue;
      if (!t.classList || !t.classList.contains('result')) continue;
      if (seen.has(t)) {
        // re-animate on subsequent updates
        t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop');
      }
      seen.add(t);
      if (t.classList.contains('lose')) {
        window.BDG.shake(t);
      }
    }
  });
  mo.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter:['class'] });
});
