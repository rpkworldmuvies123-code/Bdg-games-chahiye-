// Admin panel logic
(async function init(){
  const u = await BDG.me();
  if (!u || u.role !== 'admin'){ location.href = '/login.html?admin'; return; }
  await loadDashboard();
  // Refresh periodically
  setInterval(()=>{ if (current==='dashboard') loadDashboard(); }, 10000);
  // Wire admin link
  document.querySelectorAll('[data-username]').forEach(el => el.textContent = u.username);
  // populate game filter for bets
  const games = await fetch('/api/admin/games').then(r=>r.json());
  const sel = document.getElementById('betGame');
  games.forEach(g => sel.insertAdjacentHTML('beforeend', `<option value="${g.id}">${g.name}</option>`));
})();

let current = 'dashboard';
function show(s){
  current = s;
  document.querySelectorAll('.admin-section').forEach(el => el.style.display='none');
  document.getElementById('sec-'+s).style.display='';
  document.querySelectorAll('.navlink').forEach(el => el.classList.toggle('active', el.dataset.section===s));
  if (s==='dashboard') loadDashboard();
  if (s==='users') loadUsers();
  if (s==='transactions') loadTx();
  if (s==='bets') loadBets();
  if (s==='games') loadGames();
  if (s==='wingo') loadWingo();
  if (s==='settings') loadSettings();
}

function fmt(n){ return '₹' + Number(n||0).toFixed(2); }
function ts(t){ return new Date(t).toLocaleString(); }

async function loadDashboard(){
  const s = await fetch('/api/admin/stats').then(r=>r.json());
  const cards = [
    {label:'Total Users', val:s.users, sub:`${s.activeUsers} players`},
    {label:'Total Balance', val:fmt(s.totalBalance), sub:'across all wallets'},
    {label:'Deposits', val:fmt(s.deposits), sub:'lifetime simulated'},
    {label:'Withdrawals', val:fmt(s.withdrawals), sub:'lifetime simulated'},
    {label:'Total Bets', val:fmt(s.bets), sub:'wagered'},
    {label:'Payouts', val:fmt(s.payouts), sub:'paid out'},
    {label:'GGR (House)', val:fmt(s.ggr), sub:'Gross gaming revenue'},
    {label:'Pending Withdrawals', val:s.pendingWithdrawals, sub:'action needed'},
  ];
  document.getElementById('statGrid').innerHTML = cards.map(c=>`
    <div class="stat-card">
      <div class="label">${c.label}</div>
      <div class="val">${c.val}</div>
      <div class="sub">${c.sub}</div>
    </div>`).join('');
  document.getElementById('recentBets').innerHTML = `
    <tr><th>User</th><th>Game</th><th class="num">Stake</th><th class="num">Payout</th><th>Result</th><th>Time</th></tr>
    ${s.recentBets.map(b=>`<tr>
      <td>${b.username||'?'}</td><td>${b.game}</td>
      <td class="num">${fmt(b.stake)}</td>
      <td class="num" style="color:${b.payout>b.stake?'#9bf2c5':'#ffb0c0'}">${fmt(b.payout)}</td>
      <td style="font-size:11px;color:var(--muted)">${b.result||''}</td>
      <td style="font-size:11px;color:var(--muted)">${ts(b.ts)}</td>
    </tr>`).join('') || '<tr><td colspan="6" style="color:var(--muted)">No bets yet</td></tr>'}`;
  document.getElementById('recentTx').innerHTML = `
    <tr><th>User</th><th>Type</th><th>Method</th><th class="num">Amount</th><th>Status</th></tr>
    ${s.recentTransactions.map(t=>`<tr>
      <td>${t.username||'?'}</td>
      <td>${t.type}</td><td>${t.method}</td>
      <td class="num">${fmt(t.amount)}</td>
      <td><span class="badge ${t.status==='success'?'green':t.status==='pending'?'yellow':'red'}">${t.status}</span></td>
    </tr>`).join('') || '<tr><td colspan="5" style="color:var(--muted)">No transactions</td></tr>'}`;
}

async function loadUsers(){
  const q = document.getElementById('userSearch').value;
  const list = await fetch('/api/admin/users?q='+encodeURIComponent(q)).then(r=>r.json());
  document.getElementById('usersTbl').innerHTML = `
    <tr><th>Username</th><th>Role</th><th class="num">Balance</th><th>Joined</th><th>Status</th><th>Actions</th></tr>
    ${list.map(u=>`<tr>
      <td><b>${u.username}</b></td>
      <td><span class="badge ${u.role==='admin'?'yellow':'blue'}">${u.role}</span></td>
      <td class="num">${fmt(u.balance)}</td>
      <td style="font-size:11px;color:var(--muted)">${ts(u.createdAt)}</td>
      <td>${u.banned?'<span class="badge red">banned</span>':'<span class="badge green">active</span>'}</td>
      <td>
        <button class="icon-btn green" onclick="adjustBal('${u.id}','${u.username}')">+ Bal</button>
        <button class="icon-btn yellow" onclick="resetPwd('${u.id}','${u.username}')">Reset Pwd</button>
        <button class="icon-btn ${u.banned?'green':'red'}" onclick="toggleBan('${u.id}',${!u.banned})">${u.banned?'Unban':'Ban'}</button>
        ${u.role!=='admin'?`<button class="icon-btn red" onclick="delUser('${u.id}','${u.username}')">Delete</button>`:''}
      </td>
    </tr>`).join('')}`;
}
async function adjustBal(id, name){
  const d = prompt(`Adjust balance for ${name} (positive to credit, negative to debit):`);
  if (d==null) return;
  const r = await fetch(`/api/admin/users/${id}/adjust`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({delta:Number(d), note:'Admin manual adjust'})});
  const j = await r.json();
  if (j.ok){ BDG.toast(`New balance: ₹${j.balance.toFixed(2)}`,'win'); loadUsers(); }
  else BDG.toast(j.error,'lose');
}
async function resetPwd(id, name){
  const p = prompt(`New password for ${name}:`);
  if (!p) return;
  await fetch(`/api/admin/users/${id}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:p})});
  BDG.toast('Password reset','win');
}
async function toggleBan(id, banned){
  await fetch(`/api/admin/users/${id}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({banned})});
  loadUsers();
}
async function delUser(id, name){
  if (!confirm(`Delete user ${name}? This cannot be undone.`)) return;
  await fetch(`/api/admin/users/${id}`,{method:'DELETE'});
  loadUsers();
}

async function loadTx(){
  const type = document.getElementById('txType').value;
  const status = document.getElementById('txStatus').value;
  const q = document.getElementById('txQ').value;
  const list = await fetch(`/api/admin/transactions?type=${type}&status=${status}&q=${encodeURIComponent(q)}`).then(r=>r.json());
  document.getElementById('txTbl').innerHTML = `
    <tr><th>Time</th><th>User</th><th>Type</th><th>Method</th><th>Account</th><th class="num">Amount</th><th>Status</th><th>Actions</th></tr>
    ${list.map(t=>`<tr>
      <td style="font-size:11px;color:var(--muted)">${ts(t.ts)}</td>
      <td><b>${t.username||'?'}</b></td>
      <td><span class="badge ${t.type==='deposit'?'green':'yellow'}">${t.type}</span></td>
      <td>${t.method}</td>
      <td style="font-size:11px">${t.account||'—'}</td>
      <td class="num">${fmt(t.amount)}</td>
      <td><span class="badge ${t.status==='success'?'green':t.status==='pending'?'yellow':'red'}">${t.status}</span></td>
      <td>${t.status==='pending'?`
        <button class="icon-btn green" onclick="approveTx('${t.id}')">Approve</button>
        <button class="icon-btn red" onclick="rejectTx('${t.id}')">Reject</button>`:''}
      </td>
    </tr>`).join('') || '<tr><td colspan="8" style="color:var(--muted)">No transactions</td></tr>'}`;
}
async function approveTx(id){
  await fetch(`/api/admin/transactions/${id}/approve`,{method:'POST'});
  BDG.toast('Approved','win'); loadTx();
}
async function rejectTx(id){
  if (!confirm('Reject and refund this withdrawal?')) return;
  await fetch(`/api/admin/transactions/${id}/reject`,{method:'POST'});
  BDG.toast('Rejected & refunded','win'); loadTx();
}

async function loadBets(){
  const game = document.getElementById('betGame').value;
  const user = document.getElementById('betUser').value;
  const list = await fetch(`/api/admin/bets?game=${game}&user=${encodeURIComponent(user)}`).then(r=>r.json());
  document.getElementById('betsTbl').innerHTML = `
    <tr><th>Time</th><th>User</th><th>Game</th><th class="num">Stake</th><th class="num">Payout</th><th class="num">Net</th><th>Result</th></tr>
    ${list.map(b=>{
      const net = b.payout - b.stake;
      return `<tr>
        <td style="font-size:11px;color:var(--muted)">${ts(b.ts)}</td>
        <td><b>${b.username||'?'}</b></td><td>${b.game}</td>
        <td class="num">${fmt(b.stake)}</td>
        <td class="num">${fmt(b.payout)}</td>
        <td class="num" style="color:${net>0?'#9bf2c5':net<0?'#ffb0c0':'var(--muted)'}">${net>=0?'+':''}${fmt(net)}</td>
        <td style="font-size:11px;color:var(--muted)">${b.result||''}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="7" style="color:var(--muted)">No bets</td></tr>'}`;
}

async function loadGames(){
  const list = await fetch('/api/admin/games').then(r=>r.json());
  document.getElementById('gamesTbl').innerHTML = `
    <tr><th>Game</th><th>Status</th><th>Hot</th><th>Min Bet</th><th>Max Bet</th><th>RTP %</th><th>Plays</th><th>GGR</th><th></th></tr>
    ${list.map(g=>`<tr id="g-${g.id}">
      <td><b>${g.emoji} ${g.name}</b><div style="font-size:11px;color:var(--muted)">${g.tag}</div></td>
      <td><input type="checkbox" ${g.enabled?'checked':''} onchange="updGame('${g.id}',{enabled:this.checked})"/></td>
      <td><input type="checkbox" ${g.hot?'checked':''} onchange="updGame('${g.id}',{hot:this.checked})"/></td>
      <td><input class="input" style="width:80px" type="number" value="${g.minBet}" onchange="updGame('${g.id}',{minBet:+this.value})"/></td>
      <td><input class="input" style="width:100px" type="number" value="${g.maxBet}" onchange="updGame('${g.id}',{maxBet:+this.value})"/></td>
      <td><input class="input" style="width:70px" type="number" value="${g.rtp}" min="50" max="99" onchange="updGame('${g.id}',{rtp:+this.value})"/></td>
      <td class="num">${g.plays||0}</td>
      <td class="num" style="color:${g.ggr>=0?'#9bf2c5':'#ffb0c0'}">${fmt(g.ggr||0)}</td>
      <td><a class="icon-btn" href="/game.html?id=${g.id}" target="_blank">Open</a></td>
    </tr>`).join('')}`;
}
async function updGame(id, body){
  const r = await fetch(`/api/admin/games/${id}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j = await r.json();
  if (j.ok) BDG.toast('Saved','win');
  else BDG.toast(j.error,'lose');
}

async function loadWingo(){
  const j = await fetch('/api/admin/wingo/upcoming').then(r=>r.json());
  document.getElementById('wingoCurrent').textContent = `Current: ${j.period} · Next: ${j.next}`;
  document.getElementById('wgPeriod').placeholder = `next: ${j.next}`;
  const list = Object.entries(j.overrides);
  document.getElementById('wgList').innerHTML = list.length ? list.map(([p,n])=>`
    <div class="row" style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06)">
      <span>Period <b>${p}</b></span><span>→ <b style="color:var(--gold)">${n}</b></span>
      <button class="icon-btn red" onclick="rmOverride('${p}')">Remove</button>
    </div>`).join('') : '<div style="color:var(--muted);font-size:13px">No active overrides.</div>';
}
async function setOverride(){
  const period = +document.getElementById('wgPeriod').value || (Math.floor(Date.now()/60000)+1);
  const number = +document.getElementById('wgNumber').value;
  const r = await fetch('/api/admin/wingo/override',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({period,number})});
  const j = await r.json();
  if (j.ok){ BDG.toast('Override set','win'); document.getElementById('wgPeriod').value=''; document.getElementById('wgNumber').value=''; loadWingo(); }
  else BDG.toast(j.error,'lose');
}
async function rmOverride(p){
  await fetch(`/api/admin/wingo/override/${p}`,{method:'DELETE'});
  loadWingo();
}

async function loadSettings(){
  const s = await fetch('/api/admin/settings').then(r=>r.json());
  const fields = [
    {k:'siteName',label:'Site Name',type:'text'},
    {k:'startingBalance',label:'Starting Balance (₹)',type:'number'},
    {k:'minDeposit',label:'Min Deposit (₹)',type:'number'},
    {k:'minWithdraw',label:'Min Withdraw (₹)',type:'number'},
    {k:'autoApproveWithdraw',label:'Auto-approve withdrawals',type:'checkbox'},
    {k:'currency',label:'Currency Code',type:'text'},
  ];
  document.getElementById('settingsForm').innerHTML = fields.map(f=>{
    const v = s[f.k];
    if (f.type==='checkbox') return `<label style="display:flex;align-items:center;gap:10px;margin-top:10px"><input type="checkbox" id="s-${f.k}" ${v?'checked':''}/> ${f.label}</label>`;
    return `<label style="display:block;margin-top:10px"><div style="font-size:12px;color:var(--muted);margin-bottom:4px">${f.label}</div>
      <input id="s-${f.k}" class="input" type="${f.type}" value="${v}" /></label>`;
  }).join('');
}
async function saveSettings(){
  const body = {
    siteName: document.getElementById('s-siteName').value,
    startingBalance: +document.getElementById('s-startingBalance').value,
    minDeposit: +document.getElementById('s-minDeposit').value,
    minWithdraw: +document.getElementById('s-minWithdraw').value,
    autoApproveWithdraw: document.getElementById('s-autoApproveWithdraw').checked,
    currency: document.getElementById('s-currency').value,
  };
  const r = await fetch('/api/admin/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j = await r.json();
  if (j.ok) BDG.toast('Saved','win');
}
